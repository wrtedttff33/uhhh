# G8Raid —— Unity 撤离 / 副本突击项目（移动端完整版）

第三人称/第一人称 PvE 副本（Raid）玩法：无线电推进剧情 → 摩斯终端破解 →
精英敌人波次防守 → 战利品收集 → 载具驾驶 → 撤离点撤离过关。

支持移动端触控（虚拟摇杆 + 触屏视角）。

---

## 🎮 重要：不需要本地安装 Unity！

本项目内置了**一键场景生成器**（`Assets/Editor/GameSceneBuilder.cs`），
自动创建地面、玩家、敌人、AI 队友、交互物、波次防守、完整 HUD 和移动端触控界面。
**任何电脑（包括老电脑 / 无显卡）都能开发这个项目**——你只需要：

1. 把项目推到 GitHub
2. 运行自动构建（云端免费打包 APK）
3. 下载 APK 安装到手机

> 唯一需要本地做的事只有：浏览器访问 GitHub 网站、Unity 官网。不需要装任何软件。

---

## 方式一：云端自动构建 APK（推荐，无需本地 Unity）

### 1. 准备 GitHub 仓库
1. 注册一个免费账号 https://github.com/signup
2. 点右上角 **+** → **New repository**，命名如 `g8raid`，勾选 Public 或 Private，创建
3. 按 GitHub 提示把本项目文件上传/推送（上传 zip 解压后整个 G8Raid 文件夹内容推上去，含 `.github/` 目录）

> 不会用 git 命令的话：仓库创建页有 **uploading an existing file** 入口，直接把文件拖上去即可。

### 2. 第一次运行：激活 Unity 许可证（免费，一次即可）
1. 打开仓库 → **Actions** 标签 → 找到 **Build Android APK** 工作流 → **Run workflow**
2. 第一个 job（activation）会生成一个 `Unity_v2022.3.22f1.alf` 文件 → 在 **Artifacts** 里下载它
3. 用浏览器打开 https://license.unity3d.com/manual ，上传刚下载的 `.alf` 文件
4. 页面会生成一个 `.ulf` 文件 → 下载它，用记事本打开，**全选复制全部内容**
5. 回到 GitHub 仓库 → **Settings** → **Secrets and variables** → **Actions** → **New repository secret**
   - Name 填：`UNITY_LICENSE`
   - Secret 填：粘贴刚才复制的 .ulf 全部内容
   - 保存

### 3. 再次运行构建
1. 回到 **Actions** → **Build Android APK** → **Run workflow**
2. 等 15~30 分钟（云端在下载 Unity 2022.3 + Android 模块，只有第一次慢，之后有缓存）
3. 完成后在 **Artifacts** 里下载 `G8Raid-Android-APK`
4. 解压得到 `G8Raid.apk`，传到手机安装即可玩！

### 以后每次更新代码
改完代码推到 GitHub → 自动重新打包 → 下载新 APK。

---

## 方式二：有 Unity Editor 的电脑（可选）

在 Unity Hub 中 Add 本 `G8Raid` 文件夹（Unity 2022.3 LTS 或 Unity 6），
然后**完全不需要手动搭建**，直接点菜单：

**菜单栏 → G8Raid → 一键生成完整游戏场景**

它会自动生成所有内容并保存场景。然后在 Build Settings 里切 Android 打包，
或直接执行 `Assets/Editor/BuildScript.cs` 的 `BuildAndroid` 方法。

---

## 已内置的完整内容（无需手动搭建）

| 模块 | 内容 |
|---|---|
| 玩家 | 第一人称控制器 + 武器系统 + 库存（胶囊体占位模型） |
| 敌人 | 精英 AI（巡逻/追击/攻击/范围技能）+ 2 波防守 |
| 交互 | 无线电剧情、摩斯密码终端（HELP）、撤离点、战利品箱 ×3 |
| 载具 | 可驾驶吉普（按 E 上下车） |
| AI 队友 | 跟随/战斗/倒地复活 |
| 掉落 | 敌人死亡掉落战利品 + 弹药 |
| HUD | 血条/弹药/准星/任务追踪/字幕/通知/拾取提示/受伤红晕/撤离进度/小地图 |
| 结算 | 死亡统计、胜利统计、暂停菜单 |
| 移动端 | 虚拟摇杆、右侧视角、射击/换弹/交互/跳跃/疾跑/医疗包按钮 |
| 任务链 | 联络指挥部 → 破解终端 → 守住据点 → 撤离 |

## 操作说明

### 桌面端（若在编辑器/电脑上跑）
WASD 移动 / 鼠标视角 / 左键射击 / R 换弹 / E 交互 / Space 跳跃 / Shift 疾跑 / G 医疗包 / Esc 暂停

### 移动端
左下摇杆移动 / 右侧拖动视角 / 右下红钮射击 / 换弹/交互/跳跃/疾跑/医疗按钮

---

## 项目结构

```
G8Raid/
├─ Assets/
│  ├─ Editor/
│  │  ├─ GameSceneBuilder.cs   # ★ 一键生成完整场景（菜单/CI 通用）
│  │  └─ BuildScript.cs        # ★ 云端打包入口（自动生成场景 + 出 APK）
│  ├─ Scripts/                 # 36 个游戏脚本
│  │  ├─ Actor/ Weapon/ Inventory/ Raid/ Loot/ Vehicle/
│  │  ├─ UI/                   # HUD、结算、暂停、小地图
│  │  └─ Mobile/               # 虚拟摇杆、触控视角、触控按钮
│  ├─ Prefabs/                 # 敌人/队友/箱子/拾取物/载具（自动生成）
│  ├─ Scenes/                  # Raid.unity（自动生成）
│  └─ Resources/               # 武器数据/战利品数据（自动生成）
├─ Packages/manifest.json      # Unity 依赖声明
├─ ProjectSettings/            # Unity 版本锁定
├─ .github/workflows/          # 云端自动构建配置
└─ build.gradle                # Android 构建参考
```

## 玩法串联
1. 出生点附近的**无线电** → 按 E 联络指挥部（任务1）
2. 找到**电脑** → 输入摩斯密码 `HELP`（E=点，Q=划，回车提交）（任务2）
3. 前往基地西侧**防守据点** → 击退 2 波敌人（任务3）
4. 打开**战利品箱**、捡**敌人掉落**，可以开**载具**快速移动
5. 前往**撤离点**（黄色圆柱）→ 停留 5 秒 → 通关结算

## Android 构建参数（已内置）
- 包名：`com.g8raid.game`，产品名：G8Raid
- 最低 Android 7.0（API 24），目标 Android 14（API 34）
- IL2CPP + Release 配置
