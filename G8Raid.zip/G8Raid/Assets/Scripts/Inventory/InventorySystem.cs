using System.Collections.Generic;
using UnityEngine;
using G8Raid.Loot;

namespace G8Raid.Inventory
{
    /// <summary>
    /// 玩家库存系统：管理战利品计数、医疗包使用、弹药储备。
    /// 挂载在玩家物体上（单例）。监听 LootItem.OnLootPicked 自动入库。
    /// </summary>
    public class InventorySystem : MonoBehaviour
    {
        public static InventorySystem Instance { get; private set; }

        [Header("初始物品")]
        public int startingMedkits = 2;
        public int startingAmmoReserve = 120;

        public Dictionary<string, int> Items { get; private set; } = new Dictionary<string, int>();
        public int Medkits { get; private set; }
        public int AmmoReserve { get; private set; }

        // 事件（UI 订阅）
        public event System.Action<string, int> OnItemAdded;       // 物品名, 数量
        public event System.Action OnInventoryChanged;
        public event System.Action<int> OnMedkitUsed;               // 剩余医疗包数

        void Awake()
        {
            Instance = this;
        }

        void Start()
        {
            Medkits = startingMedkits;
            AmmoReserve = startingAmmoReserve;
            LootItem.OnLootPicked += HandleLootPicked;
        }

        void OnDestroy()
        {
            LootItem.OnLootPicked -= HandleLootPicked;
        }

        void HandleLootPicked(LootItemData data, int amount)
        {
            if (data == null) return;

            // 特殊物品分类
            if (data.displayName.Contains("医疗") || data.displayName.Contains("Medkit") || data.displayName.Contains("药"))
            {
                Medkits += amount;
            }
            else if (data.displayName.Contains("弹药") || data.displayName.Contains("Ammo") || data.displayName.Contains("子弹"))
            {
                AmmoReserve += amount * 30;
                if (Weapon.WeaponSystem.Instance != null)
                    Weapon.WeaponSystem.Instance.AddAmmo(amount * 30);
            }

            string key = data.displayName;
            Items.TryGetValue(key, out int count);
            Items[key] = count + amount;
            OnItemAdded?.Invoke(key, amount);
            OnInventoryChanged?.Invoke();
        }

        /// <summary>使用医疗包回血（移动端按钮 / 桌面 G 键）。</summary>
        public bool UseMedkit()
        {
            if (Medkits <= 0) return false;
            var player = Actor.PlayerController.Instance;
            if (player == null || player.IsDead) return false;
            if (player.Health >= player.maxHealth) return false;

            Medkits--;
            player.Heal(50f);
            OnMedkitUsed?.Invoke(Medkits);
            OnInventoryChanged?.Invoke();
            return true;
        }

        void Update()
        {
            if (!Application.isMobilePlatform)
            {
                if (Input.GetKeyDown(KeyCode.G)) UseMedkit();
            }
        }
    }
}
