using UnityEngine;
using UnityEngine.EventSystems;

namespace G8Raid.Mobile
{
    /// <summary>
    /// 触控视角区域：在屏幕右侧区域拖拽来控制镜头旋转。
    /// 输出每帧的 LookDelta（相对屏幕像素的拖动增量，需乘灵敏度）。
    /// 挂在全屏 UI 矩形上，EventSystem 需存在。
    /// </summary>
    public class TouchLookArea : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [Tooltip("灵敏度（每像素旋转角度）")]
        public float sensitivity = 0.15f;

        public Vector2 LookDelta { get; private set; }

        private int _touchId = -999;
        private Vector2 _lastPos;

        public void OnPointerDown(PointerEventData e)
        {
            _touchId = e.pointerId;
            _lastPos = e.position;
            LookDelta = Vector2.zero;
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != _touchId) return;
            Vector2 delta = e.position - _lastPos;
            _lastPos = e.position;
            LookDelta = new Vector2(delta.x * sensitivity, delta.y * sensitivity);
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId != _touchId) return;
            _touchId = -999;
            LookDelta = Vector2.zero;
        }

        void LateUpdate()
        {
            LookDelta = Vector2.zero;
        }
    }
}
