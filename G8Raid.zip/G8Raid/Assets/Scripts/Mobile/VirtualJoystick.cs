using UnityEngine;
using UnityEngine.EventSystems;

namespace G8Raid.Mobile
{
    /// <summary>
    /// 虚拟摇杆：挂在 UI 图片上，支持拖拽输出 Vector2 方向。
    /// 输出 Value 范围 [-1, 1]。
    /// </summary>
    public class VirtualJoystick : MonoBehaviour, IPointerDownHandler, IDragHandler, IPointerUpHandler
    {
        [Header("摇杆")]
        public RectTransform background;
        public RectTransform handle;
        public float radius = 100f;

        public Vector2 Value { get; private set; }

        private int _touchId = -999;

        public void OnPointerDown(PointerEventData e)
        {
            _touchId = e.pointerId;
            OnDrag(e);
        }

        public void OnDrag(PointerEventData e)
        {
            if (e.pointerId != _touchId) return;

            RectTransformUtility.ScreenPointToLocalPointInRectangle(
                background, e.position, e.pressEventCamera, out Vector2 pos);

            pos = Vector2.ClampMagnitude(pos, radius);
            handle.anchoredPosition = pos;
            Value = pos / radius;
        }

        public void OnPointerUp(PointerEventData e)
        {
            if (e.pointerId != _touchId) return;
            _touchId = -999;
            Value = Vector2.zero;
            handle.anchoredPosition = Vector2.zero;
        }
    }
}
