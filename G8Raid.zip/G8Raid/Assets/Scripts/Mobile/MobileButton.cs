using UnityEngine;
using UnityEngine.Events;
using UnityEngine.EventSystems;

namespace G8Raid.Mobile
{
    /// <summary>
    /// 移动端触控按钮：支持点击、按下、释放三种事件。
    /// 挂在 UI Button 上，自动替换为自定义事件。
    /// </summary>
    public class MobileButton : MonoBehaviour, IPointerDownHandler, IPointerUpHandler, IPointerClickHandler
    {
        public UnityEvent onClick = new UnityEvent();
        public UnityEvent onPress = new UnityEvent();
        public UnityEvent onRelease = new UnityEvent();

        public bool IsPressed { get; private set; }

        public void OnPointerDown(PointerEventData e)
        {
            IsPressed = true;
            onPress?.Invoke();
        }

        public void OnPointerUp(PointerEventData e)
        {
            IsPressed = false;
            onRelease?.Invoke();
        }

        public void OnPointerClick(PointerEventData e)
        {
            onClick?.Invoke();
        }
    }
}
