using UnityEngine;
using G8Raid.Actor;
using G8Raid.Weapon;

namespace G8Raid.Mobile
{
    /// <summary>
    /// 移动端输入总控：在移动端激活虚拟摇杆和触控按钮，
    /// 将触控输入写入 PlayerController 和 WeaponSystem 的公开字段。
    /// 桌面端自动禁用。
    /// 挂载在 Canvas 或场景空物体上。
    /// </summary>
    public class MobileInputManager : MonoBehaviour
    {
        public static MobileInputManager Instance { get; private set; }

        [Header("触控 UI 引用")]
        public VirtualJoystick moveJoystick;
        public TouchLookArea lookArea;
        public MobileButton fireButton;
        public MobileButton aimButton;
        public MobileButton reloadButton;
        public MobileButton interactButton;
        public MobileButton jumpButton;
        public MobileButton sprintButton;
        public MobileButton medkitButton;

        void Awake()
        {
            Instance = this;
        }

        void Start()
        {
            bool mobile = Application.isMobilePlatform;
            if (moveJoystick != null) moveJoystick.gameObject.SetActive(mobile);
            if (lookArea != null) lookArea.gameObject.SetActive(mobile);
            if (fireButton != null) fireButton.gameObject.SetActive(mobile);
            if (aimButton != null) aimButton.gameObject.SetActive(mobile);
            if (reloadButton != null) reloadButton.gameObject.SetActive(mobile);
            if (interactButton != null) interactButton.gameObject.SetActive(mobile);
            if (jumpButton != null) jumpButton.gameObject.SetActive(mobile);
            if (sprintButton != null) sprintButton.gameObject.SetActive(mobile);
            if (medkitButton != null) medkitButton.gameObject.SetActive(mobile);

            if (!mobile) return;

            // 绑定事件
            if (fireButton != null)
            {
                fireButton.onPress.AddListener(() => {
                    if (WeaponSystem.Instance != null) {
                        WeaponSystem.Instance.inputFire = true;
                        WeaponSystem.Instance.inputFireHeld = true;
                    }
                });
                fireButton.onRelease.AddListener(() => {
                    if (WeaponSystem.Instance != null)
                        WeaponSystem.Instance.inputFireHeld = false;
                });
            }

            if (reloadButton != null)
                reloadButton.onClick.AddListener(() => {
                    if (WeaponSystem.Instance != null) WeaponSystem.Instance.inputReload = true;
                });

            if (interactButton != null)
                interactButton.onClick.AddListener(() => {
                    if (PlayerController.Instance != null)
                        PlayerController.Instance.inputInteract = true;
                });

            if (jumpButton != null)
                jumpButton.onClick.AddListener(() => {
                    if (PlayerController.Instance != null)
                        PlayerController.Instance.inputJump = true;
                });

            if (medkitButton != null)
                medkitButton.onClick.AddListener(() => {
                    if (Inventory.InventorySystem.Instance != null)
                        Inventory.InventorySystem.Instance.UseMedkit();
                });
        }

        void Update()
        {
            if (!Application.isMobilePlatform) return;
            if (PlayerController.Instance == null) return;

            // 移动摇杆 → PlayerController
            if (moveJoystick != null)
                PlayerController.Instance.moveInput = moveJoystick.Value;

            // 疾跑
            if (sprintButton != null)
                PlayerController.Instance.inputSprint = sprintButton.IsPressed;

            // 视角拖动 → PlayerController 视角
            if (lookArea != null)
            {
                PlayerController pc = PlayerController.Instance;
                float mx = lookArea.LookDelta.x;
                float my = lookArea.LookDelta.y;
                if (pc != null && !pc.IsDead)
                {
                    pc.transform.Rotate(0f, mx, 0f);
                    pc.ApplyLookPitch(my);
                }
            }
        }
    }
}
