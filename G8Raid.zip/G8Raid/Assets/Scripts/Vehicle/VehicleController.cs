using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Vehicle
{
    /// <summary>
    /// 可驾驶载具：加速 / 转向 / 手刹 / 燃油消耗。
    /// 玩家靠近后按 E 进入驾驶，驾驶中按 E 下车。
    /// 需要：Rigidbody + Collider + 本脚本；cameraMount 为驾驶视角相机挂点。
    /// 输入：桌面 WASD / 空格（手刹）；移动端 UI 写入 driveInput / inputBrake。
    /// </summary>
    [RequireComponent(typeof(Rigidbody))]
    public class VehicleController : MonoBehaviour, IInteractable
    {
        // —— IInteractable 实现 ——
        public string InteractionPrompt =>
            IsDriven ? "按 E 下车" : "按 E 驾驶载具";
        public bool CanInteract => true;

        public void OnInteract(PlayerController player)
        {
            if (IsDriven) Exit();
            else TryEnter(player);
        }
        [Header("动力")]
        public float enginePower = 1500f;
        public float maxSpeed = 40f;
        public float brakePower = 2500f;
        public float turnSpeed = 2.2f;
        public float steerLerp = 8f;

        [Header("燃油")]
        public float maxFuel = 100f;
        public float fuelConsumePerSec = 0.5f;

        [Header("相机")]
        public Transform cameraMount;   // 驾驶时相机挂点

        public float Fuel { get; private set; }
        public bool IsDriven { get; private set; }

        public event System.Action<VehicleController> OnPlayerEnter;
        public event System.Action<VehicleController> OnPlayerExit;

        private Rigidbody _rb;
        private float _steer;
        private bool _braking;

        // 移动端 UI 写入的输入状态
        [HideInInspector] public Vector2 driveInput; // x=转向(-1..1) y=油门(-1..1)
        [HideInInspector] public bool inputBrake;

        void Awake()
        {
            _rb = GetComponent<Rigidbody>();
            Fuel = maxFuel;
        }

        void Update()
        {
            if (!IsDriven) return;

            if (!Application.isMobilePlatform)
            {
                driveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
                inputBrake = Input.GetKey(KeyCode.Space);
            }

            _steer = Mathf.Lerp(_steer, driveInput.x, steerLerp * Time.deltaTime);
        }

        void FixedUpdate()
        {
            if (!IsDriven || Fuel <= 0f) return;

            float throttle = Mathf.Clamp(driveInput.y, -1f, 1f);
            if (Mathf.Abs(throttle) > 0.01f)
                Fuel = Mathf.Max(0f, Fuel - fuelConsumePerSec * Mathf.Abs(throttle) * Time.fixedDeltaTime);

            // 转向：仅在有速度时生效
            float speed = _rb.velocity.magnitude;
            if (speed > 0.5f)
            {
                float steerAngle = _steer * turnSpeed * Mathf.Sign(speed);
                Quaternion rot = Quaternion.Euler(0f, steerAngle * Mathf.Rad2Deg * Time.fixedDeltaTime, 0f);
                _rb.MoveRotation(_rb.rotation * rot);
            }

            if (inputBrake)
            {
                _rb.AddForce(-_rb.velocity * brakePower, ForceMode.Acceleration);
            }
            else if (Mathf.Abs(throttle) > 0.01f)
            {
                Vector3 forward = transform.forward * Mathf.Sign(throttle);
                _rb.AddForce(forward * enginePower * Time.fixedDeltaTime, ForceMode.Acceleration);

                // 限速
                if (_rb.velocity.magnitude > maxSpeed)
                    _rb.velocity = _rb.velocity.normalized * maxSpeed;
            }
        }

        /// <summary>玩家尝试进入载具（UI 交互键调用）。</summary>
        public bool TryEnter(PlayerController player)
        {
            if (IsDriven || player == null) return false;

            IsDriven = true;
            player.SetControlLocked(true);
            OnPlayerEnter?.Invoke(this);
            return true;
        }

        /// <summary>离开载具，恢复玩家控制。</summary>
        public void Exit()
        {
            if (!IsDriven) return;

            IsDriven = false;
            if (PlayerController.Instance != null)
                PlayerController.Instance.SetControlLocked(false);
            OnPlayerExit?.Invoke(this);
        }

        void OnDisable()
        {
            if (IsDriven) Exit();
        }
    }
}
