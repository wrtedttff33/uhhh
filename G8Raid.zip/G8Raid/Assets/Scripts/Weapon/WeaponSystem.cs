using UnityEngine;
using G8Raid.Actor;
using G8Raid.Raid;

namespace G8Raid.Weapon
{
    /// <summary>
    /// 玩家武器系统：射击（hitscan）、换弹、散布、后坐力、弹药管理。
    /// 挂载在玩家物体上，muzzle 为枪口挂点（用于特效），hitLayers 配置敌人所在层。
    ///
    /// 桌面端输入：鼠标左键开火，R 换弹。
    /// 移动端：MobileInputManager 写入 inputFire / inputReload / inputFireHeld。
    /// </summary>
    public class WeaponSystem : MonoBehaviour
    {
        public static WeaponSystem Instance { get; private set; }

        [Header("武器配置")]
        public WeaponData currentWeapon;

        [Header("引用")]
        public Transform muzzle;
        public Camera playerCamera;
        [Tooltip("射击命中检测的层")] public LayerMask hitLayers = ~0;

        [Header("输入（移动端写入）")]
        [HideInInspector] public bool inputFire;      // 单次点击（半自动用）
        [HideInInspector] public bool inputFireHeld;   // 按住（全自动用）
        [HideInInspector] public bool inputReload;

        // —— 状态 ——
        public int CurrentAmmo { get; private set; }
        public int ReserveAmmo { get; private set; }
        public bool IsReloading { get; private set; }
        public float CurrentSpread { get; private set; }

        private float _nextFireTime;
        private float _reloadEndTime;
        private AudioSource _audio;

        // 事件（UI 订阅）
        public event System.Action<int, int> OnAmmoChanged;       // 当前弹, 后备弹
        public event System.Action OnShotFired;
        public event System.Action OnReloadStart;
        public event System.Action OnReloadComplete;
        public event System.Action<Vector3> OnHitEnemy;            // 命中点

        void Awake()
        {
            Instance = this;
            _audio = GetComponent<AudioSource>();
            if (_audio == null) _audio = gameObject.AddComponent<AudioSource>();
            _audio.playOnAwake = false;
        }

        void Start()
        {
            if (currentWeapon != null)
            {
                CurrentAmmo = currentWeapon.magSize;
                ReserveAmmo = currentWeapon.magSize * 4;
            }
            OnAmmoChanged?.Invoke(CurrentAmmo, ReserveAmmo);
        }

        void Update()
        {
            if (PlayerController.Instance != null && PlayerController.Instance.IsDead) return;
            if (IsReloading)
            {
                if (Time.time >= _reloadEndTime) FinishReload();
                return;
            }

            if (!Application.isMobilePlatform)
            {
                inputFire = Input.GetMouseButtonDown(0);
                inputFireHeld = Input.GetMouseButton(0);
                if (Input.GetKeyDown(KeyCode.R)) inputReload = true;
            }

            if (inputReload)
            {
                inputReload = false;
                TryReload();
            }

            bool wantFire = currentWeapon.fireMode == FireMode.Automatic ? inputFireHeld : inputFire;
            if (wantFire && Time.time >= _nextFireTime)
                Fire();

            // 散布恢复
            CurrentSpread = Mathf.Max(GetBaseSpread(), CurrentSpread - currentWeapon.spreadRecover * Time.deltaTime);
        }

        float GetBaseSpread()
        {
            bool moving = PlayerController.Instance != null &&
                          PlayerController.Instance.moveInput.sqrMagnitude > 0.1f;
            return moving ? currentWeapon.spreadMoving : currentWeapon.spreadIdle;
        }

        void Fire()
        {
            if (currentWeapon == null) return;

            if (CurrentAmmo <= 0)
            {
                PlayClip(currentWeapon.emptyClip);
                _nextFireTime = Time.time + 0.25f;
                TryReload();
                return;
            }

            CurrentAmmo--;
            _nextFireTime = Time.time + 60f / currentWeapon.roundsPerMinute;
            CurrentSpread += currentWeapon.spreadPerShot;
            OnAmmoChanged?.Invoke(CurrentAmmo, ReserveAmmo);

            // 射线检测
            Vector3 origin = playerCamera != null ? playerCamera.transform.position : transform.position;
            Vector3 direction = playerCamera != null ? playerCamera.transform.forward : transform.forward;
            direction = ApplySpread(direction);

            if (Physics.Raycast(origin, direction, out RaycastHit hit, currentWeapon.range, hitLayers))
            {
                // 命中敌人？
                var enemy = hit.collider.GetComponentInParent<EnemyEliteAI>();
                if (enemy != null && !enemy.IsDead)
                {
                    enemy.TakeDamage(currentWeapon.damage, transform);
                    OnHitEnemy?.Invoke(hit.point);
                }

                // 命中队友？不伤害
                var teammate = hit.collider.GetComponentInParent<AITeammate>();
                if (teammate != null) { /* friendly fire off */ }

                // 命中特效
                if (currentWeapon.hitEffectPrefab != null)
                    Instantiate(currentWeapon.hitEffectPrefab, hit.point, Quaternion.LookRotation(hit.normal));
            }

            // 枪口特效
            if (muzzle != null && currentWeapon.muzzleFlashPrefab != null)
            {
                var flash = Instantiate(currentWeapon.muzzleFlashPrefab, muzzle.position, muzzle.rotation, muzzle);
                Destroy(flash, currentWeapon.muzzleFlashDuration);
            }

            PlayClip(currentWeapon.shootClip);
            OnShotFired?.Invoke();

            if (CurrentAmmo <= 0) TryReload();
        }

        Vector3 ApplySpread(Vector3 direction)
        {
            float angle = CurrentSpread;
            float rx = Random.Range(-angle, angle);
            float ry = Random.Range(-angle, angle);
            return Quaternion.Euler(rx, ry, 0f) * direction;
        }

        public void TryReload()
        {
            if (IsReloading || currentWeapon == null) return;
            if (CurrentAmmo >= currentWeapon.magSize) return;
            if (ReserveAmmo <= 0) return;

            IsReloading = true;
            _reloadEndTime = Time.time + currentWeapon.reloadTime;
            PlayClip(currentWeapon.reloadClip);
            OnReloadStart?.Invoke();
        }

        void FinishReload()
        {
            int need = currentWeapon.magSize - CurrentAmmo;
            int take = Mathf.Min(need, ReserveAmmo);
            CurrentAmmo += take;
            ReserveAmmo -= take;
            IsReloading = false;
            OnAmmoChanged?.Invoke(CurrentAmmo, ReserveAmmo);
            OnReloadComplete?.Invoke();
        }

        public void AddAmmo(int amount)
        {
            ReserveAmmo += amount;
            OnAmmoChanged?.Invoke(CurrentAmmo, ReserveAmmo);
        }

        public void SetWeapon(WeaponData weapon)
        {
            currentWeapon = weapon;
            CurrentAmmo = weapon.magSize;
            ReserveAmmo = weapon.magSize * 4;
            IsReloading = false;
            OnAmmoChanged?.Invoke(CurrentAmmo, ReserveAmmo);
        }

        void PlayClip(AudioClip clip)
        {
            if (clip == null || _audio == null) return;
            _audio.PlayOneShot(clip);
        }
    }
}
