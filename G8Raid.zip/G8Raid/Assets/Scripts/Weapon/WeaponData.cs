using UnityEngine;

namespace G8Raid.Weapon
{
    public enum FireMode
    {
        Semi,       // 半自动：按一下打一发
        Automatic   // 全自动：按住连发
    }

    /// <summary>
    /// 武器配置数据（ScriptableObject）。
    /// Project 窗口右键 → Create → G8Raid/Weapon 创建实例。
    /// </summary>
    [CreateAssetMenu(fileName = "Weapon", menuName = "G8Raid/Weapon")]
    public class WeaponData : ScriptableObject
    {
        [Header("基础")]
        public string weaponName = "Assault Rifle";
        public FireMode fireMode = FireMode.Automatic;

        [Header("伤害 / 射速")]
        public float damage = 25f;
        [Tooltip("每分钟射速")] public float roundsPerMinute = 600f;
        [Tooltip("有效射程（米）")] public float range = 80f;

        [Header("弹匣")]
        public int magSize = 30;
        public float reloadTime = 2.2f;

        [Header("精度")]
        [Tooltip("静止时散布角度（度）")] public float spreadIdle = 0.8f;
        [Tooltip("移动时散布角度")] public float spreadMoving = 2.5f;
        [Tooltip("每发子弹增加的散布")] public float spreadPerShot = 0.15f;
        [Tooltip("散布恢复速度")] public float spreadRecover = 3f;

        [Header("音效 / 表现")]
        public AudioClip shootClip;
        public AudioClip reloadClip;
        public AudioClip emptyClip;
        public GameObject muzzleFlashPrefab;
        public GameObject hitEffectPrefab;
        public float muzzleFlashDuration = 0.05f;
    }
}
