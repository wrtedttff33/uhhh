using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Loot
{
    public enum LootContainerType
    {
        Crate,        // 木箱
        Chest,        // 宝箱
        SupplyCache   // 补给箱
    }

    /// <summary>
    /// 可开启的战利品容器：玩家交互后播放开启动画，
    /// 生成可拾取战利品（pickupPrefab 带 LootItem 组件）或直接发放，
    /// 开启后完成绑定任务。
    /// 需要：Collider(Is Trigger) + 本脚本 + 可选 Animator(Trigger "Open")。
    /// </summary>
    public class LootContainer : MonoBehaviour, IInteractable
    {
        [Header("容器")]
        public LootContainerType containerType = LootContainerType.Crate;
        [Tooltip("必定掉落的战利品")]
        public List<LootItemData> guaranteedDrops = new List<LootItemData>();
        [Tooltip("随机掉落数量")]
        public int randomDropCount = 2;
        [Tooltip("随机掉落候选池")]
        public LootItemData[] possibleRandomDrops;
        [Tooltip("为 true 时生成可拾取的 pickupPrefab，否则直接发放")]
        public bool dropPickupPrefab = true;
        [Tooltip("带 LootItem 组件的拾取物预制体")]
        public GameObject pickupPrefab;

        [Header("任务绑定")]
        public string taskIdOnOpened;

        public bool IsOpened { get; private set; }

        public string InteractionPrompt => IsOpened ? "已开启" : "按 E 搜索";
        public bool CanInteract => !IsOpened;

        public event System.Action<LootContainer> OnOpened;

        private Animator _anim;
        private bool _opening;

        void Awake()
        {
            _anim = GetComponent<Animator>();
        }

        public void OnInteract(PlayerController player)
        {
            if (!CanInteract || _opening) return;
            StartCoroutine(OpenSequence());
        }

        IEnumerator OpenSequence()
        {
            _opening = true;

            if (_anim != null) _anim.SetTrigger("Open");
            yield return new WaitForSeconds(0.35f);

            foreach (LootItemData item in guaranteedDrops)
                if (item != null) SpawnOrGrant(item);

            if (possibleRandomDrops != null && possibleRandomDrops.Length > 0)
            {
                for (int i = 0; i < randomDropCount; i++)
                {
                    LootItemData r = possibleRandomDrops[Random.Range(0, possibleRandomDrops.Length)];
                    if (r != null) SpawnOrGrant(r);
                }
            }

            IsOpened = true;
            _opening = false;
            OnOpened?.Invoke(this);

            if (G8Raid.Raid.TaskSystem.Instance != null && !string.IsNullOrEmpty(taskIdOnOpened))
                G8Raid.Raid.TaskSystem.Instance.CompleteObjective(taskIdOnOpened);
        }

        void SpawnOrGrant(LootItemData data)
        {
            if (dropPickupPrefab && pickupPrefab != null)
            {
                GameObject go = Instantiate(
                    pickupPrefab,
                    transform.position + Vector3.up * 0.6f + Random.insideUnitSphere * 0.4f,
                    Quaternion.identity);
                LootItem loot = go.GetComponent<LootItem>();
                if (loot != null) loot.data = data;
            }
            else
            {
                LootItem.OnLootPicked?.Invoke(data, 1);
                if (G8Raid.Raid.TaskSystem.Instance != null)
                    G8Raid.Raid.TaskSystem.Instance.Notify("拾取战利品", data.displayName + " ×1");
            }
        }
    }
}
