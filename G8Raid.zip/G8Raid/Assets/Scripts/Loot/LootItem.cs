using UnityEngine;

namespace G8Raid.Loot
{
    public enum LootRarity
    {
        Common,     // 普通
        Uncommon,   // 优秀
        Rare,       // 稀有
        Epic,       // 史诗
        Legendary   // 传说
    }

    /// <summary>
    /// 战利品配置数据（ScriptableObject）。
    /// 在 Project 窗口右键 → Create → G8Raid/Loot Item 创建实例。
    /// </summary>
    [CreateAssetMenu(fileName = "LootItem", menuName = "G8Raid/Loot Item")]
    public class LootItemData : ScriptableObject
    {
        public string displayName = "战利品";
        public LootRarity rarity = LootRarity.Common;
        public Sprite icon;
        [TextArea] public string description;
        public int value = 1;
    }

    /// <summary>
    /// 场景中的可拾取战利品：玩家进入拾取半径即获得（吸附 + 浮动表现）。
    /// 拾取后触发静态事件 OnLootPicked 并弹提示。
    /// 需要：Collider(Is Trigger) + 本脚本；data 指向 LootItemData 资源。
    /// </summary>
    public class LootItem : MonoBehaviour
    {
        [Header("配置")]
        public LootItemData data;
        public int amount = 1;
        public float pickupRadius = 0.6f;
        [Tooltip("近距离吸附速度")]
        public float magnetSpeed = 6f;
        public float despawnAfter = 60f;

        [Header("表现")]
        public float bobSpeed = 2f;
        public float bobHeight = 0.25f;

        /// <summary>拾取事件（data, 数量），UI / 库存可订阅。</summary>
        public static event System.Action<LootItemData, int> OnLootPicked;

        private Vector3 _startPos;
        private float _time;

        void Start()
        {
            _startPos = transform.position;
            if (despawnAfter > 0) Destroy(gameObject, despawnAfter);
        }

        void Update()
        {
            // 浮动
            _time += Time.deltaTime;
            transform.position = _startPos + Vector3.up * (Mathf.Sin(_time * bobSpeed) * bobHeight);

            var player = G8Raid.Actor.PlayerController.Instance;
            if (player == null) return;

            float dist = Vector3.Distance(transform.position, player.transform.position);
            if (dist <= pickupRadius)
            {
                PickUp();
            }
            else if (dist <= pickupRadius * 3f)
            {
                // 近距离吸附到玩家
                transform.position = Vector3.MoveTowards(
                    transform.position, player.transform.position + Vector3.up * 0.8f,
                    magnetSpeed * Time.deltaTime);
            }
        }

        void PickUp()
        {
            OnLootPicked?.Invoke(data, amount);
            if (G8Raid.Raid.TaskSystem.Instance != null && data != null)
                G8Raid.Raid.TaskSystem.Instance.Notify("拾取战利品", data.displayName + " ×" + amount);
            Destroy(gameObject);
        }
    }
}
