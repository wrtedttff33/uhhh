using UnityEngine;
using UnityEngine.UI;

namespace G8Raid.UI
{
    public class InteractionPromptUI : MonoBehaviour
    {
        public GameObject background;
        public Text promptText;

        public void Show(string prompt, bool canInteract)
        {
            if (background != null)
                background.SetActive(!string.IsNullOrEmpty(prompt));
            if (promptText != null)
            {
                promptText.text = prompt;
                promptText.color = canInteract ? Color.white : Color.gray;
            }
        }
    }
}
