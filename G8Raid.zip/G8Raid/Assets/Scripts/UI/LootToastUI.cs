using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace G8Raid.UI
{
    public class LootToastUI : MonoBehaviour
    {
        public Text toastText;
        public float displayDuration = 2f;

        void Start()
        {
            G8Raid.Loot.LootItem.OnLootPicked += (data, amt) => {
                if (data != null) ShowToast("获得: " + data.displayName + " ×" + amt);
            };
        }

        void ShowToast(string msg)
        {
            if (toastText != null)
            {
                toastText.text = msg;
                StopCoroutine(nameof(FadeOut));
                StartCoroutine(nameof(FadeOut));
            }
        }

        IEnumerator FadeOut()
        {
            toastText.gameObject.SetActive(true);
            yield return new WaitForSeconds(displayDuration);
            toastText.gameObject.SetActive(false);
        }
    }
}
