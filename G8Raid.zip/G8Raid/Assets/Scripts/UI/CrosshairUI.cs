using UnityEngine;
using UnityEngine.UI;

namespace G8Raid.UI
{
    public class CrosshairUI : MonoBehaviour
    {
        public RectTransform crosshair;
        public float spreadAmount = 5f;
        public float spreadLerp = 10f;

        private Vector3 _baseScale = Vector3.one;

        void Start() { _baseScale = crosshair.localScale; }

        void Update()
        {
            float spread = 1f;
            if (Weapon.WeaponSystem.Instance != null)
                spread = 1f + Weapon.WeaponSystem.Instance.CurrentSpread / 2f;

            Vector3 target = _baseScale * spread;
            crosshair.localScale = Vector3.Lerp(crosshair.localScale, target, spreadLerp * Time.deltaTime);
        }

        public void ShowHitMarker(float duration = 0.15f)
        {
            // 可以在这里缩放/变色准星
            if (crosshair != null)
                LeanTweenUtil.ScalePunch(crosshair.gameObject, 1.3f, duration);
        }
    }

    /// <summary>轻量补间工具（避免依赖 DOTween）。</summary>
    public static class LeanTweenUtil
    {
        public static void ScalePunch(GameObject go, float punch, float duration)
        {
            var c = go.AddComponent<ScalePunch>();
            c.punch = punch;
            c.duration = duration;
        }
    }

    public class ScalePunch : MonoBehaviour
    {
        public float punch = 1.3f;
        public float duration = 0.15f;
        Vector3 _orig;
        float _t;

        void Awake() { _orig = transform.localScale; }
        void Update()
        {
            _t += Time.deltaTime;
            float p = 1f - Mathf.PingPong(_t / duration, 1f) * (punch - 1f);
            transform.localScale = _orig * p;
            if (_t >= duration * 2f) { transform.localScale = _orig; Destroy(this); }
        }
    }
}
