using UnityEngine;
using UnityEngine.UI;
using G8Raid.Raid;

namespace G8Raid.UI
{
    public class PauseMenuUI : MonoBehaviour
    {
        public GameObject panel;
        public Button resumeButton;
        public Button restartButton;
        public Button quitButton;

        void Start()
        {
            panel.SetActive(false);
            GameManager.Instance.OnGamePaused += () => panel.SetActive(true);
            GameManager.Instance.OnGameResumed += () => panel.SetActive(false);
            resumeButton.onClick.AddListener(() => GameManager.Instance.Resume());
            restartButton.onClick.AddListener(() => { GameManager.Instance.Resume(); GameManager.Instance.RestartLevel(); });
            quitButton.onClick.AddListener(() => GameManager.Instance.ReturnToMainMenu());
        }
    }
}
