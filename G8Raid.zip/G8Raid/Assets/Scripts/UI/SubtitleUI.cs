using UnityEngine;
using UnityEngine.UI;

namespace G8Raid.UI
{
    public class SubtitleUI : MonoBehaviour
    {
        public Text subtitleText;
        public GameObject background;

        public void Show(string text)
        {
            bool hasText = !string.IsNullOrEmpty(text);
            if (background != null) background.SetActive(hasText);
            if (subtitleText != null) subtitleText.text = text;
        }
    }
}
