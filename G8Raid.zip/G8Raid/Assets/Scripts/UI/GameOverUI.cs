using UnityEngine;
using UnityEngine.UI;
using G8Raid.Raid;

namespace G8Raid.UI
{
    public class GameOverUI : MonoBehaviour
    {
        public GameObject panel;
        public Text statsText;
        public Button restartButton;
        public Button mainMenuButton;

        void Start()
        {
            panel.SetActive(false);
            GameManager.Instance.OnStateChanged += OnStateChanged;
            restartButton.onClick.AddListener(() => GameManager.Instance.RestartLevel());
            mainMenuButton.onClick.AddListener(() => GameManager.Instance.ReturnToMainMenu());
        }

        void OnStateChanged(GameState state)
        {
            if (state == GameState.Dead)
            {
                panel.SetActive(true);
                if (statsText != null && GameManager.Instance != null)
                {
                    var gm = GameManager.Instance;
                    statsText.text = "击杀敌人: " + gm.enemiesKilled + "\n" +
                                     "收集战利品: " + gm.lootCollected + "\n" +
                                     "存活时间: " + Mathf.FloorToInt(gm.sessionTime) + "秒";
                }
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
        }
    }
}
