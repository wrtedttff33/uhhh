using UnityEngine;
using UnityEngine.UI;
using G8Raid.Raid;

namespace G8Raid.UI
{
    public class DamageVignetteUI : MonoBehaviour
    {
        public Image vignetteImage;
        public float fadeSpeed = 3f;

        void Start()
        {
            if (PlayerController.Instance != null)
                PlayerController.Instance.OnHealthChanged += OnHealthChanged;
            SetAlpha(0);
        }

        void OnHealthChanged(float current, float max)
        {
            float ratio = 1f - (current / max);
            SetAlpha(ratio);
        }

        void Update()
        {
            if (PlayerController.Instance != null && PlayerController.Instance.Health > 50f)
            {
                Color c = vignetteImage.color;
                c.a = Mathf.Lerp(c.a, 0f, fadeSpeed * Time.deltaTime);
                vignetteImage.color = c;
            }
        }

        void SetAlpha(float a)
        {
            if (vignetteImage != null)
            {
                Color c = vignetteImage.color;
                c.a = a;
                vignetteImage.color = c;
            }
        }
    }
}
