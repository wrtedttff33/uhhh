using UnityEngine;
using UnityEngine.UI;
using G8Raid.Raid;

namespace G8Raid.UI
{
    public class MissionTrackerUI : MonoBehaviour
    {
        public Text titleText;
        public Text descText;

        void Start() { Refresh(); }

        public void Refresh()
        {
            if (TaskSystem.Instance == null || TaskSystem.Instance.Current == null)
            {
                if (titleText != null) titleText.text = "任务完成";
                if (descText != null) descText.text = "前往撤离点";
                return;
            }
            var obj = TaskSystem.Instance.Current;
            if (titleText != null) titleText.text = obj.title;
            if (descText != null) descText.text = obj.description;
        }
    }
}
