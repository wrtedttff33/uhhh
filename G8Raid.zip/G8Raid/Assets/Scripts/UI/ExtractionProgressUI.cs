using UnityEngine;
using UnityEngine.UI;
using G8Raid.Raid;

namespace G8Raid.UI
{
    public class ExtractionProgressUI : MonoBehaviour
    {
        public GameObject panel;
        public Image fillImage;
        public Text statusText;

        void Start()
        {
            EvacuatePoint.OnAnyExtractionStart += HandleStart;
            EvacuatePoint.OnAnyExtractionProgress += HandleProgress;
            EvacuatePoint.OnAnyExtractionComplete += HandleComplete;
            EvacuatePoint.OnAnyExtractionCancel += HandleCancel;
            panel.SetActive(false);
        }

        void OnDestroy()
        {
            EvacuatePoint.OnAnyExtractionStart -= HandleStart;
            EvacuatePoint.OnAnyExtractionProgress -= HandleProgress;
            EvacuatePoint.OnAnyExtractionComplete -= HandleComplete;
            EvacuatePoint.OnAnyExtractionCancel -= HandleCancel;
        }

        void HandleStart()
        {
            panel.SetActive(true);
            if (statusText != null) statusText.text = "正在撤离...";
        }

        void HandleProgress(float p)
        {
            if (fillImage != null) fillImage.fillAmount = p;
        }

        void HandleComplete()
        {
            panel.SetActive(false);
        }

        void HandleCancel()
        {
            panel.SetActive(false);
        }
    }
}
