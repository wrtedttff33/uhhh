using UnityEngine;
using UnityEngine.UI;
using System.Collections;

namespace G8Raid.UI
{
    public class NotifyUI : MonoBehaviour
    {
        public Text titleText;
        public Text messageText;
        public float displayDuration = 3f;

        void Start()
        {
            if (titleText != null) titleText.gameObject.SetActive(false);
            if (messageText != null) messageText.gameObject.SetActive(false);
        }

        public void ShowNotification(string title, string message)
        {
            StopAllCoroutines();
            StartCoroutine(ShowRoutine(title, message));
        }

        IEnumerator ShowRoutine(string title, string message)
        {
            if (titleText != null) { titleText.text = title; titleText.gameObject.SetActive(true); }
            if (messageText != null) { messageText.text = message; messageText.gameObject.SetActive(true); }
            yield return new WaitForSeconds(displayDuration);
            if (titleText != null) titleText.gameObject.SetActive(false);
            if (messageText != null) messageText.gameObject.SetActive(false);
        }
    }
}
