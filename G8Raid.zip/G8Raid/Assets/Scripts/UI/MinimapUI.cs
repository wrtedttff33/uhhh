using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;

namespace G8Raid.UI
{
    /// <summary>
    /// 小地图：将 MapMarker.All 中的标记渲染为 UI 圆点。
    /// 挂载在小地图 RawImage/RectTransform 上。
    /// </summary>
    public class MinimapUI : MonoBehaviour
    {
        public RectTransform mapRect;
        public RectTransform markerPrefab;
        [Tooltip("世界坐标到地图坐标的缩放")]
        public float mapScale = 0.1f;
        [Tooltip("地图中心（世界坐标）")]
        public Vector3 mapCenter = Vector3.zero;

        private readonly Dictionary<MapMarker, RectTransform> _markers = new Dictionary<MapMarker, RectTransform>();

        void OnEnable()
        {
            MapMarker.OnMarkerRegistered += AddMarker;
            MapMarker.OnMarkerUnregistered += RemoveMarker;
            foreach (var m in MapMarker.All) AddMarker(m);
        }

        void OnDisable()
        {
            MapMarker.OnMarkerRegistered -= AddMarker;
            MapMarker.OnMarkerUnregistered -= RemoveMarker;
        }

        void AddMarker(MapMarker marker)
        {
            if (markerPrefab == null || mapRect == null || !marker.visible) return;
            var go = Instantiate(markerPrefab, mapRect);
            go.gameObject.SetActive(true);
            _markers[marker] = go;
        }

        void RemoveMarker(MapMarker marker)
        {
            if (_markers.TryGetValue(marker, out var go))
            {
                Destroy(go.gameObject);
                _markers.Remove(marker);
            }
        }

        void Update()
        {
            if (mapRect == null) return;
            foreach (var kv in _markers)
            {
                var marker = kv.Key;
                var ui = kv.Value;
                Vector3 local = (marker.WorldPosition - mapCenter) * mapScale;
                ui.anchoredPosition = new Vector2(local.x, local.z);
            }
        }
    }
}
