using UnityEngine;
using UnityEngine.UI;

namespace G8Raid.UI
{
    public class HealthBarUI : MonoBehaviour
    {
        public Image fillImage;
        public Text healthText;

        public void SetHealth(float current, float max)
        {
            if (fillImage != null)
                fillImage.fillAmount = current / max;
            if (healthText != null)
                healthText.text = Mathf.CeilToInt(current) + " / " + Mathf.CeilToInt(max);
        }
    }
}
