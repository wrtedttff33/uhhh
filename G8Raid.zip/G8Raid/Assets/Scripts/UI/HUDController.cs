using UnityEngine;
using UnityEngine.UI;
using G8Raid.Actor;
using G8Raid.Raid;

namespace G8Raid.UI
{
    /// <summary>
    /// HUD 总控制器：管理所有 HUD 元素的显隐和数据绑定。
    /// 挂载在 HUD Canvas 上。
    /// </summary>
    public class HUDController : MonoBehaviour
    {
        [Header("子 UI")]
        public HealthBarUI healthBar;
        public AmmoCounterUI ammoCounter;
        public InteractionPromptUI interactPrompt;
        public MissionTrackerUI missionTracker;
        public LootToastUI lootToast;
        public SubtitleUI subtitle;
        public DamageVignetteUI damageVignette;
        public ExtractionProgressUI extractionProgress;
        public CrosshairUI crosshair;

        [Header("屏幕提示")]
        public NotifyUI notifyUI;

        void Start()
        {
            // 订阅玩家事件
            if (PlayerController.Instance != null)
            {
                PlayerController.Instance.OnHealthChanged += (cur, max) => {
                    if (healthBar != null) healthBar.SetHealth(cur, max);
                };
                PlayerController.Instance.OnInteractableChanged += (target) => {
                    if (interactPrompt != null)
                        interactPrompt.Show(target != null ? target.InteractionPrompt : string.Empty,
                                           target != null && target.CanInteract);
                };
            }

            // 订阅任务系统
            if (TaskSystem.Instance != null)
            {
                TaskSystem.Instance.OnSubtitle += (text) => {
                    if (subtitle != null) subtitle.Show(text);
                };
                TaskSystem.Instance.OnNotify += (title, msg) => {
                    if (notifyUI != null) notifyUI.ShowNotification(title, msg);
                };
                TaskSystem.Instance.OnObjectiveCompleted += (obj) => {
                    if (missionTracker != null) missionTracker.Refresh();
                };
            }
        }
    }
}
