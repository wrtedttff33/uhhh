using UnityEngine;
using UnityEngine.UI;
using G8Raid.Weapon;

namespace G8Raid.UI
{
    public class AmmoCounterUI : MonoBehaviour
    {
        public Text ammoText;
        public Text reloadText;

        void Start()
        {
            if (WeaponSystem.Instance != null)
            {
                WeaponSystem.Instance.OnAmmoChanged += UpdateAmmo;
                WeaponSystem.Instance.OnReloadStart += () => {
                    if (reloadText != null) reloadText.gameObject.SetActive(true);
                };
                WeaponSystem.Instance.OnReloadComplete += () => {
                    if (reloadText != null) reloadText.gameObject.SetActive(false);
                };
                UpdateAmmo(WeaponSystem.Instance.CurrentAmmo, WeaponSystem.Instance.ReserveAmmo);
            }
        }

        void UpdateAmmo(int current, int reserve)
        {
            if (ammoText != null)
                ammoText.text = current + " / " + reserve;
        }
    }
}
