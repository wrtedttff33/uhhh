using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using G8Raid.Raid;

namespace G8Raid.Actor
{
    public enum EnemyState
    {
        Patrol,     // 巡逻
        Chase,      // 追击
        Attack,     // 攻击
        Staggered,  // 精英技能蓄力（硬直）
        Dead
    }

    /// <summary>
    /// 精英敌人 AI：巡逻 → 追击 → 攻击 状态机，含精英技能（范围震击）。
    /// 使用 NavMeshAgent 寻路（需在场景中烘焙 NavMesh；无 Agent 时退化为直线追踪）。
    /// 死亡后触发 OnDeath 事件（DefendWave / LootContainer 可订阅处理掉落）。
    /// </summary>
    public class EnemyEliteAI : MonoBehaviour
    {
        /// <summary>当前场景所有存活的精英敌人（供 AI 队友索敌）。</summary>
        public static readonly List<EnemyEliteAI> All = new List<EnemyEliteAI>();

        /// <summary>全局任意敌人死亡事件（掉落/统计用）。</summary>
        public static event System.Action<EnemyEliteAI> OnAnyEnemyDeath;

        [Header("基础")]
        public float maxHealth = 180f;
        public float moveSpeed = 3.5f;
        public float turnSpeed = 720f;

        [Header("感知")]
        [Tooltip("视野半径")]
        public float viewRadius = 18f;
        [Tooltip("视野张角（度）")]
        public float viewAngle = 110f;
        [Tooltip("听力半径：视野外但极近时也能察觉")]
        public float hearingRadius = 8f;

        [Header("攻击")]
        public float attackRange = 2.2f;
        public float attackDamage = 20f;
        public float attackCooldown = 1.4f;

        [Header("精英技能")]
        public bool hasEliteSkill = true;
        public float skillCooldown = 8f;
        public float skillRadius = 5f;
        public float skillDamage = 35f;

        [Header("巡逻路径")]
        public Transform[] patrolPoints;

        public float Health { get; private set; }
        public bool IsDead => State == EnemyState.Dead;
        public EnemyState State { get; private set; } = EnemyState.Patrol;

        public event System.Action<EnemyEliteAI> OnDeath;
        public event System.Action<EnemyEliteAI, float> OnHealthChanged;

        private NavMeshAgent _agent;
        private Transform _player;
        private int _patrolIndex;
        private float _nextAttack;
        private float _nextSkill;
        private bool _skillExecuting;

        void Awake()
        {
            _agent = GetComponent<NavMeshAgent>();
            Health = maxHealth;
        }

        void OnEnable() { if (!All.Contains(this)) All.Add(this); }
        void OnDisable() { All.Remove(this); }

        void Start()
        {
            if (PlayerController.Instance != null) _player = PlayerController.Instance.transform;
            if (_agent != null)
            {
                _agent.speed = moveSpeed;
                SetNextPatrolPoint();
            }
            State = EnemyState.Patrol;
        }

        void Update()
        {
            if (IsDead) return;
            if (_player == null && PlayerController.Instance != null)
                _player = PlayerController.Instance.transform;

            if (CanSeePlayer()) State = EnemyState.Chase;

            switch (State)
            {
                case EnemyState.Patrol: PatrolUpdate(); break;
                case EnemyState.Chase: ChaseUpdate(); break;
                case EnemyState.Attack: AttackUpdate(); break;
            }

            // 精英技能：追击中周期性释放
            if (hasEliteSkill && !_skillExecuting && State == EnemyState.Chase && Time.time >= _nextSkill)
                StartCoroutine(ExecuteEliteSkill());
        }

        bool CanSeePlayer()
        {
            if (_player == null) return false;

            Vector3 dir = _player.position - transform.position;
            float dist = dir.magnitude;
            if (dist > viewRadius) return false;

            if (Vector3.Angle(transform.forward, dir.normalized) > viewAngle * 0.5f)
                return dist <= hearingRadius; // 视野外但贴近

            // 视线遮挡检测
            if (Physics.Raycast(transform.position + Vector3.up, dir.normalized, out RaycastHit hit, dist))
                return hit.transform == _player;

            return true;
        }

        void PatrolUpdate()
        {
            if (_agent == null || !_agent.enabled || !_agent.isOnNavMesh) return;

            if (!_agent.pathPending && _agent.remainingDistance <= _agent.stoppingDistance + 0.1f)
                SetNextPatrolPoint();
        }

        void SetNextPatrolPoint()
        {
            if (patrolPoints == null || patrolPoints.Length == 0) return;
            _patrolIndex = (_patrolIndex + 1) % patrolPoints.Length;
            Transform p = patrolPoints[_patrolIndex];
            if (p != null && _agent != null && _agent.isOnNavMesh)
                _agent.SetDestination(p.position);
        }

        void ChaseUpdate()
        {
            if (_player == null) { State = EnemyState.Patrol; return; }

            float dist = Vector3.Distance(transform.position, _player.position);
            if (dist <= attackRange)
            {
                State = EnemyState.Attack;
                return;
            }

            if (_agent != null && _agent.enabled && _agent.isOnNavMesh)
            {
                _agent.SetDestination(_player.position);
            }
            else
            {
                Vector3 dir = (_player.position - transform.position).normalized;
                transform.position += dir * moveSpeed * Time.deltaTime;
                transform.rotation = Quaternion.RotateTowards(
                    transform.rotation, Quaternion.LookRotation(dir), turnSpeed * Time.deltaTime);
            }
        }

        void AttackUpdate()
        {
            if (_player == null) { State = EnemyState.Patrol; return; }

            Vector3 dir = _player.position - transform.position;
            dir.y = 0f;
            if (dir.sqrMagnitude > 0.001f)
                transform.rotation = Quaternion.RotateTowards(
                    transform.rotation, Quaternion.LookRotation(dir.normalized), turnSpeed * Time.deltaTime);

            if (Time.time >= _nextAttack)
            {
                _nextAttack = Time.time + attackCooldown;
                if (PlayerController.Instance != null)
                {
                    PlayerController.Instance.TakeDamage(attackDamage);
                    if (TaskSystem.Instance != null)
                        TaskSystem.Instance.Notify("受伤", "受到精英敌人攻击 -" + attackDamage);
                }
            }
        }

        IEnumerator ExecuteEliteSkill()
        {
            _skillExecuting = true;
            _nextSkill = Time.time + skillCooldown;
            State = EnemyState.Staggered;

            // 起手蓄力（预留动画触发点）
            yield return new WaitForSeconds(0.6f);

            if (PlayerController.Instance != null &&
                Vector3.Distance(transform.position, PlayerController.Instance.transform.position) <= skillRadius)
            {
                PlayerController.Instance.TakeDamage(skillDamage);
                if (TaskSystem.Instance != null)
                    TaskSystem.Instance.Notify("精英技能", "地面震荡！受到 " + skillDamage + " 点伤害");
            }

            State = EnemyState.Chase;
            _skillExecuting = false;
        }

        public void TakeDamage(float amount, Transform source = null)
        {
            if (IsDead) return;

            Health = Mathf.Max(0f, Health - amount);
            OnHealthChanged?.Invoke(this, Health);

            if (source != null)
            {
                PlayerController pc = source.GetComponentInParent<PlayerController>();
                if (pc != null) _player = pc.transform;
                State = EnemyState.Chase; // 受击索敌
            }

            if (Health <= 0f) Die();
        }

        void Die()
        {
            State = EnemyState.Dead;
            if (_agent != null) _agent.enabled = false;

            OnDeath?.Invoke(this);
            OnAnyEnemyDeath?.Invoke(this);

            // 死亡表现后销毁（预留掉落由外部监听 OnDeath 生成）
            StartCoroutine(DeathRoutine());
        }

        IEnumerator DeathRoutine()
        {
            yield return new WaitForSeconds(0.8f);
            if (gameObject != null) Destroy(gameObject);
        }

        void OnDrawGizmosSelected()
        {
            Gizmos.color = Color.red;
            Gizmos.DrawWireSphere(transform.position, viewRadius);
        }
    }
}
