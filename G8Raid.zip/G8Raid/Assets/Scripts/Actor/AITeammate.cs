using UnityEngine;
using G8Raid.Raid;

namespace G8Raid.Actor
{
    public enum TeammateState
    {
        Idle,
        Follow,
        Combat,
        Down
    }

    /// <summary>
    /// AI 队友：跟随玩家，自动索敌并提供火力支援；可倒地并由玩家复活。
    /// 敌人使用 EnemyEliteAI（注册于 EnemyEliteAI.All）。
    /// 需要：可选 CharacterController（用于移动）。
    /// </summary>
    public class AITeammate : MonoBehaviour, IInteractable
    {
        // —— IInteractable：倒地时可复活 ——
        public string InteractionPrompt =>
            IsDown ? "按 E 复活队友" : string.Empty;
        public bool CanInteract => IsDown;

        public void OnInteract(PlayerController player)
        {
            if (IsDown) Revive();
        }

        [Header("行为")]
        public float followDistance = 2.2f;
        public float followSpeed = 4.5f;
        public float detectionRadius = 25f;
        public float attackRange = 20f;
        public float fireCooldown = 0.4f;
        public int damagePerShot = 12;

        [Header("生命")]
        public float maxHealth = 100f;

        public TeammateState State { get; private set; } = TeammateState.Idle;
        public float Health { get; private set; }
        public bool IsDown { get; private set; }

        public event System.Action<AITeammate> OnDown;
        public event System.Action<AITeammate> OnRevived;

        private Transform _player;
        private EnemyEliteAI _target;
        private float _nextFire;
        private CharacterController _cc;

        void Awake()
        {
            _cc = GetComponent<CharacterController>();
            Health = maxHealth;
        }

        void Start()
        {
            if (PlayerController.Instance != null) _player = PlayerController.Instance.transform;
            State = TeammateState.Follow;
        }

        void Update()
        {
            if (IsDown) return;
            if (_player == null && PlayerController.Instance != null)
                _player = PlayerController.Instance.transform;

            UpdateTarget();

            if (_target != null && !_target.IsDead &&
                Vector3.Distance(transform.position, _target.transform.position) <= attackRange)
            {
                State = TeammateState.Combat;
            }
            else
            {
                State = TeammateState.Follow;
            }

            switch (State)
            {
                case TeammateState.Combat: CombatUpdate(); break;
                case TeammateState.Follow:
                default: FollowUpdate(); break;
            }
        }

        void UpdateTarget()
        {
            _target = null;
            float bestSqr = detectionRadius * detectionRadius;
            foreach (EnemyEliteAI e in EnemyEliteAI.All)
            {
                if (e == null || e.IsDead) continue;
                float d = (e.transform.position - transform.position).sqrMagnitude;
                if (d < bestSqr) { bestSqr = d; _target = e; }
            }
        }

        void FollowUpdate()
        {
            if (_player == null) return;

            Vector3 toPlayer = _player.position - transform.position;
            toPlayer.y = 0f;
            if (toPlayer.magnitude <= followDistance) return;

            Vector3 dir = toPlayer.normalized;
            transform.rotation = Quaternion.LookRotation(dir);

            if (_cc != null) _cc.Move(dir * followSpeed * Time.deltaTime);
            else transform.position += dir * followSpeed * Time.deltaTime;
        }

        void CombatUpdate()
        {
            if (_target == null || _target.IsDead) return;

            Vector3 toTarget = _target.transform.position - transform.position;
            toTarget.y = 0f;
            transform.rotation = Quaternion.LookRotation(toTarget.normalized);

            // 超出射程则向目标靠近
            if (toTarget.magnitude > attackRange)
            {
                Vector3 dir = toTarget.normalized;
                if (_cc != null) _cc.Move(dir * followSpeed * Time.deltaTime);
                else transform.position += dir * followSpeed * Time.deltaTime;
            }

            if (Time.time >= _nextFire)
            {
                _nextFire = Time.time + fireCooldown;
                Vector3 origin = transform.position + Vector3.up * 1.5f;
                if (Physics.Raycast(origin, transform.forward, out RaycastHit hit, attackRange))
                {
                    EnemyEliteAI enemy = hit.collider.GetComponentInParent<EnemyEliteAI>();
                    if (enemy != null) enemy.TakeDamage(damagePerShot, transform);
                }
            }
        }

        public void TakeDamage(float amount)
        {
            if (IsDown) return;
            Health = Mathf.Max(0f, Health - amount);
            if (Health <= 0f) GoDown();
        }

        void GoDown()
        {
            IsDown = true;
            State = TeammateState.Down;
            OnDown?.Invoke(this);
        }

        /// <summary>玩家靠近交互时调用以复活队友。</summary>
        public void Revive()
        {
            if (!IsDown) return;
            Health = maxHealth;
            IsDown = false;
            State = TeammateState.Follow;
            OnRevived?.Invoke(this);
        }
    }
}
