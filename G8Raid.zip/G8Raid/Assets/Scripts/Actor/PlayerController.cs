using UnityEngine;
using G8Raid.Raid;

namespace G8Raid.Actor
{
    /// <summary>所有可交互物体实现的接口（无线电、终端、箱子、载具等）。</summary>
    public interface IInteractable
    {
        /// <summary>交互提示文案，空串表示不显示提示。</summary>
        string InteractionPrompt { get; }
        bool CanInteract { get; }
        void OnInteract(PlayerController player);
    }

    /// <summary>
    /// 第一人称玩家控制器：移动 / 跳跃 / 疾跑 / 视角 / 生命 / 交互（射线检测）。
    /// 需要：CharacterController + 本脚本；cameraPivot 为挂摄像机的空物体（本地 X 轴俯仰）。
    /// 交互键：桌面按 E；移动端 UI 按钮向 inputInteract 写入 true。
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerController : MonoBehaviour
    {
        public static PlayerController Instance { get; private set; }

        [Header("移动")]
        public float walkSpeed = 4.2f;
        public float sprintSpeed = 7.2f;
        public float acceleration = 12f;
        public float jumpHeight = 1.4f;
        public float gravity = -20f;

        [Header("视角 / 交互")]
        public float lookSensitivity = 2f;
        public Transform cameraPivot;
        public Camera playerCamera;
        public float interactRange = 3f;

        [Header("生命")]
        public float maxHealth = 100f;

        public float Health { get; private set; }
        public bool IsDead { get; private set; }

        // 移动端 UI 写入的输入状态（桌面端由 Update 自动读取）
        [HideInInspector] public Vector2 moveInput;
        [HideInInspector] public bool inputSprint;
        [HideInInspector] public bool inputJump;
        [HideInInspector] public bool inputInteract;

        // 事件
        public event System.Action<float, float> OnHealthChanged;   // 当前值, 最大值
        public event System.Action OnPlayerDeath;
        public event System.Action<IInteractable> OnInteractableChanged;

        private CharacterController _cc;
        private Vector3 _velocity;
        private float _pitch;
        private IInteractable _currentTarget;
        private bool _controlLocked;

        void Awake()
        {
            Instance = this;
            _cc = GetComponent<CharacterController>();
            Health = maxHealth;
            if (playerCamera == null) playerCamera = Camera.main;
        }

        void Start()
        {
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }

        void Update()
        {
            if (IsDead) return;

            if (!Application.isMobilePlatform) ReadDesktopInput();

            HandleLook();
            HandleMove();
            HandleInteract();
        }

        void ReadDesktopInput()
        {
            moveInput = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
            inputSprint = Input.GetKey(KeyCode.LeftShift);
            if (Input.GetKeyDown(KeyCode.Space)) inputJump = true;
            if (Input.GetKeyDown(KeyCode.E)) inputInteract = true;
        }

        void HandleLook()
        {
            if (_controlLocked) return;

            float mx = Input.GetAxis("Mouse X") * lookSensitivity;
            float my = Input.GetAxis("Mouse Y") * lookSensitivity;

            transform.Rotate(0f, mx, 0f);
            _pitch = Mathf.Clamp(_pitch - my, -80f, 80f);
            if (cameraPivot != null)
                cameraPivot.localRotation = Quaternion.Euler(_pitch, 0f, 0f);
        }

        void HandleMove()
        {
            Vector3 forward = transform.forward;
            Vector3 right = transform.right;
            Vector3 wish = forward * moveInput.y + right * moveInput.x;
            if (wish.sqrMagnitude > 1f) wish.Normalize();

            float speed = inputSprint ? sprintSpeed : walkSpeed;
            Vector3 targetVel = wish * speed;

            _velocity.x = Mathf.Lerp(_velocity.x, targetVel.x, acceleration * Time.deltaTime);
            _velocity.z = Mathf.Lerp(_velocity.z, targetVel.z, acceleration * Time.deltaTime);

            if (_cc.isGrounded && _velocity.y < 0f) _velocity.y = -2f;

            if (inputJump && _cc.isGrounded)
            {
                _velocity.y = Mathf.Sqrt(jumpHeight * -2f * gravity);
                inputJump = false;
            }
            _velocity.y += gravity * Time.deltaTime;

            _cc.Move(_velocity * Time.deltaTime);
        }

        void HandleInteract()
        {
            IInteractable target = null;
            if (playerCamera != null &&
                Physics.Raycast(playerCamera.transform.position, playerCamera.transform.forward,
                    out RaycastHit hit, interactRange))
            {
                target = hit.collider.GetComponentInParent<IInteractable>();
            }

            if (target != _currentTarget)
            {
                _currentTarget = target;
                OnInteractableChanged?.Invoke(target);
            }

            if (inputInteract)
            {
                inputInteract = false;
                if (_currentTarget != null && _currentTarget.CanInteract)
                    _currentTarget.OnInteract(this);
            }
        }

        public void TakeDamage(float amount)
        {
            if (IsDead) return;
            Health = Mathf.Max(0f, Health - amount);
            OnHealthChanged?.Invoke(Health, maxHealth);
            if (Health <= 0f) Die();
        }

        public void Heal(float amount)
        {
            if (IsDead) return;
            Health = Mathf.Min(maxHealth, Health + amount);
            OnHealthChanged?.Invoke(Health, maxHealth);
        }

        void Die()
        {
            IsDead = true;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            OnPlayerDeath?.Invoke();
        }

        /// <summary>锁定 / 解锁玩家控制（驾驶载具、播放剧情时使用）。</summary>
        public void SetControlLocked(bool locked) => _controlLocked = locked;

        /// <summary>移动端外部直接设置俯仰角增量（TouchLookArea 调用）。</summary>
        public void ApplyLookPitch(float deltaY)
        {
            if (_controlLocked) return;
            _pitch = Mathf.Clamp(_pitch - deltaY * lookSensitivity, -80f, 80f);
            if (cameraPivot != null)
                cameraPivot.localRotation = Quaternion.Euler(_pitch, 0f, 0f);
        }
    }
}
