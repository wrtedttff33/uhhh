using System;
using System.Collections.Generic;
using UnityEngine;

namespace G8Raid.Raid
{
    public enum MarkerType
    {
        Objective,   // 主线目标
        Evacuation,  // 撤离点
        Enemy,       // 敌人
        Loot,        // 战利品
        Vehicle,     // 载具
        Ally         // 友军/队友
    }

    /// <summary>
    /// 地图标记：挂在任意场景物体上即可向小地图 / 大地图注册一个点位，
    /// 静态列表 All 与注册事件供 UI 订阅更新。可配合 Canvas 指针或小地图渲染。
    /// </summary>
    public class MapMarker : MonoBehaviour
    {
        /// <summary>当前场景所有已启用标记。</summary>
        public static readonly List<MapMarker> All = new List<MapMarker>();

        [Header("标记")]
        public MarkerType markerType = MarkerType.Objective;
        public string label = "目标点";
        public Color color = Color.white;
        public Sprite icon;
        [Tooltip("为 false 时小地图不显示该标记")]
        public bool visible = true;

        public Vector3 WorldPosition => transform.position;

        public static event Action<MapMarker> OnMarkerRegistered;
        public static event Action<MapMarker> OnMarkerUnregistered;

        void OnEnable()
        {
            if (!All.Contains(this)) All.Add(this);
            OnMarkerRegistered?.Invoke(this);
        }

        void OnDisable()
        {
            All.Remove(this);
            OnMarkerUnregistered?.Invoke(this);
        }

        public float DistanceTo(Vector3 position) => Vector3.Distance(position, WorldPosition);

        void OnDrawGizmosSelected()
        {
            Gizmos.color = color;
            Gizmos.DrawWireSphere(WorldPosition, 1f);
        }
    }
}
