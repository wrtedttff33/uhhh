using System.Collections;
using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Raid
{
    /// <summary>
    /// 撤离点：玩家进入并停留指定秒数即完成撤离（过关）。
    /// 可通过 requireTaskUnlocked 限制必须在 TaskSystem.extractionAllowed = true 后才可撤离。
    /// 需要：Collider(Is Trigger) + 本脚本，玩家物体 Tag 设为 "Player"。
    /// </summary>
    public class EvacuatePoint : MonoBehaviour
    {
        [Header("撤离设置")]
        [Tooltip("玩家需在点内停留的秒数")]
        public float requiredStay = 5f;
        [Tooltip("为 true 时要求 TaskSystem.extractionAllowed 开启才能撤离")]
        public bool requireTaskUnlocked = true;
        [Tooltip("撤离完成后完成的任务 id")]
        public string taskIdOnComplete = "evacuate";

        public bool IsExtracting { get; private set; }
        /// <summary>撤离进度 0~1，供 UI 进度条使用。</summary>
        public float Progress { get; private set; }

        public event System.Action OnExtractionStarted;
        public event System.Action<float> OnExtractionProgress;
        public event System.Action OnExtractionComplete;

        // 全局静态事件（UI 无需引用具体撤离点）
        public static event System.Action OnAnyExtractionStart;
        public static event System.Action<float> OnAnyExtractionProgress;
        public static event System.Action OnAnyExtractionComplete;
        public static event System.Action OnAnyExtractionCancel;

        private Coroutine _countdown;

        void OnTriggerEnter(Collider other)
        {
            if (other.CompareTag("Player") && CanExtract())
                StartExtraction();
        }

        void OnTriggerExit(Collider other)
        {
            if (other.CompareTag("Player"))
                CancelExtraction();
        }

        bool CanExtract()
        {
            if (requireTaskUnlocked && TaskSystem.Instance != null && !TaskSystem.Instance.extractionAllowed)
            {
                TaskSystem.Instance.Notify("撤离", "尚未到达撤离阶段");
                return false;
            }
            return true;
        }

        void StartExtraction()
        {
            if (IsExtracting) return;
            IsExtracting = true;
            OnExtractionStarted?.Invoke();
            OnAnyExtractionStart?.Invoke();
            _countdown = StartCoroutine(Countdown());
        }

        IEnumerator Countdown()
        {
            Progress = 0f;
            float t = 0f;
            while (t < requiredStay)
            {
                t += Time.deltaTime;
                Progress = Mathf.Clamp01(t / requiredStay);
                OnExtractionProgress?.Invoke(Progress);
                OnAnyExtractionProgress?.Invoke(Progress);
                yield return null;
            }
            Complete();
        }

        void Complete()
        {
            IsExtracting = false;
            OnExtractionComplete?.Invoke();
            OnAnyExtractionComplete?.Invoke();

            if (TaskSystem.Instance != null)
            {
                TaskSystem.Instance.Notify("撤离成功", "任务完成！");
                if (!string.IsNullOrEmpty(taskIdOnComplete))
                    TaskSystem.Instance.CompleteObjective(taskIdOnComplete);
            }

            // 触发胜利
            if (GameManager.Instance != null)
                GameManager.Instance.TriggerVictory();
        }

        void CancelExtraction()
        {
            if (!IsExtracting) return;
            IsExtracting = false;
            if (_countdown != null) StopCoroutine(_countdown);
            OnAnyExtractionCancel?.Invoke();

            if (TaskSystem.Instance != null)
                TaskSystem.Instance.Notify("撤离", "撤离中止");
        }
    }
}
