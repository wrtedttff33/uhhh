using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Raid
{
    /// <summary>
    /// 波次防守系统：按配置依次生成精英敌人波次，
    /// 全部波次清空后完成绑定任务（如"守住据点"）。
    /// 需要：挂载到防守区域管理物体上，敌人需带 EnemyEliteAI。
    /// </summary>
    public class DefendWave : MonoBehaviour
    {
        [System.Serializable]
        public class WaveConfig
        {
            public string name = "波次 1";
            [Tooltip("本波次刷新的敌人预制体（需带 EnemyEliteAI）")]
            public EnemyEliteAI enemyPrefab;
            public int count = 5;
            public float spawnInterval = 1.2f;
            public Transform[] spawnPoints;
        }

        [Header("波次配置")]
        public WaveConfig[] waves;
        public bool autoStart = true;
        public float startDelay = 2f;
        [Tooltip("全部波次清空后完成的任务 id")]
        public string taskIdOnCleared = "defend_area";

        public int CurrentWave { get; private set; } = -1;
        public int AliveEnemies { get; private set; }
        public bool AllCleared { get; private set; }

        public event System.Action<int> OnWaveStarted;  // 波次下标
        public event System.Action<int> OnWaveCleared;  // 波次下标
        public event System.Action OnAllWavesCleared;

        private readonly List<EnemyEliteAI> _enemies = new List<EnemyEliteAI>();

        void Start()
        {
            if (autoStart) StartCoroutine(RunWaves());
        }

        IEnumerator RunWaves()
        {
            yield return new WaitForSeconds(startDelay);

            for (int i = 0; i < waves.Length; i++)
            {
                yield return StartCoroutine(SpawnWave(i));
                yield return new WaitUntil(() => AliveEnemies <= 0);

                OnWaveCleared?.Invoke(i);
                if (TaskSystem.Instance != null)
                    TaskSystem.Instance.Notify("防守完成", "第 " + (i + 1) + " 波敌人已清除");
            }

            AllCleared = true;
            OnAllWavesCleared?.Invoke();
            if (TaskSystem.Instance != null && !string.IsNullOrEmpty(taskIdOnCleared))
                TaskSystem.Instance.CompleteObjective(taskIdOnCleared);
        }

        IEnumerator SpawnWave(int index)
        {
            WaveConfig cfg = waves[index];
            CurrentWave = index;
            OnWaveStarted?.Invoke(index);
            if (TaskSystem.Instance != null)
                TaskSystem.Instance.Notify("警报", "第 " + (index + 1) + " 波敌人来袭！");

            for (int i = 0; i < cfg.count; i++)
            {
                SpawnEnemy(cfg);
                yield return new WaitForSeconds(cfg.spawnInterval);
            }
        }

        void SpawnEnemy(WaveConfig cfg)
        {
            if (cfg.enemyPrefab == null) return;

            Transform spawn = cfg.spawnPoints != null && cfg.spawnPoints.Length > 0
                ? cfg.spawnPoints[Random.Range(0, cfg.spawnPoints.Length)]
                : transform;

            EnemyEliteAI enemy = Instantiate(cfg.enemyPrefab, spawn.position, spawn.rotation);
            enemy.OnDeath += HandleEnemyDeath;
            _enemies.Add(enemy);
            AliveEnemies++;
        }

        void HandleEnemyDeath(EnemyEliteAI enemy)
        {
            if (_enemies.Remove(enemy)) AliveEnemies--;
        }

        void OnDestroy()
        {
            foreach (EnemyEliteAI e in _enemies)
                if (e != null) e.OnDeath -= HandleEnemyDeath;
        }
    }
}
