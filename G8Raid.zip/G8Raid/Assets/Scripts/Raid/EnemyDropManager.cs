using UnityEngine;
using G8Raid.Actor;
using G8Raid.Loot;

namespace G8Raid.Raid
{
    /// <summary>
    /// 敌人死亡掉落系统：挂在防守区域或全局物体上，
    /// 监听所有 EnemyEliteAI.OnDeath，按概率生成战利品拾取物。
    /// </summary>
    public class EnemyDropManager : MonoBehaviour
    {
        [Header("掉落配置")]
        [Tooltip("普通敌人必掉战利品预制体（带 LootItem）")]
        public GameObject[] guaranteedDrops;
        [Range(0f, 1f)] public float dropChance = 0.6f;
        [Tooltip("随机掉落候选")]
        public LootItemData[] randomDrops;
        public float dropSpread = 1.5f;

        [Header("弹药补给")]
        public GameObject ammoPickupPrefab;
        public float ammoDropChance = 0.4f;

        void OnEnable()
        {
            EnemyEliteAI.OnAnyEnemyDeath += HandleEnemyDeath;
        }

        void OnDisable()
        {
            EnemyEliteAI.OnAnyEnemyDeath -= HandleEnemyDeath;
        }

        void HandleEnemyDeath(EnemyEliteAI enemy)
        {
            if (GameManager.Instance != null)
                GameManager.Instance.RegisterKill();

            Vector3 pos = enemy.transform.position + Vector3.up * 0.5f;

            // 必掉
            if (guaranteedDrops != null)
            {
                foreach (var prefab in guaranteedDrops)
                {
                    if (prefab == null) continue;
                    Vector3 offset = Random.insideUnitSphere * dropSpread;
                    offset.y = 0;
                    Instantiate(prefab, pos + offset, Quaternion.identity);
                }
            }

            // 随机掉落
            if (randomDrops != null && randomDrops.Length > 0 && Random.value < dropChance)
            {
                var data = randomDrops[Random.Range(0, randomDrops.Length)];
                if (data != null && ammoPickupPrefab != null)
                {
                    var go = Instantiate(ammoPickupPrefab, pos + Random.insideUnitSphere * dropSpread, Quaternion.identity);
                    var loot = go.GetComponent<LootItem>();
                    if (loot != null) loot.data = data;
                }
            }

            // 弹药补给
            if (ammoPickupPrefab != null && Random.value < ammoDropChance)
            {
                var go = Instantiate(ammoPickupPrefab, pos + Random.insideUnitSphere * dropSpread, Quaternion.identity);
                var loot = go.GetComponent<LootItem>();
                if (loot != null)
                {
                    loot.data = ScriptableObject.CreateInstance<LootItemData>();
                    loot.data.displayName = "弹药";
                    loot.data.rarity = LootRarity.Common;
                    loot.data.value = 30;
                }
            }
        }
    }
}
