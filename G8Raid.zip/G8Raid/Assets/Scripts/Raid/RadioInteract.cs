using System.Collections;
using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Raid
{
    /// <summary>
    /// 可交互无线电：玩家靠近后按交互键，依次播放台词字幕 / 语音，
    /// 播完自动完成绑定的任务（例如"与指挥部联络"），推进主线剧情。
    /// 需要：Collider(Is Trigger) + 本脚本 + 可选 AudioSource。
    /// </summary>
    public class RadioInteract : MonoBehaviour, IInteractable
    {
        [Header("广播内容")]
        public string radioName = "便携无线电";
        [Tooltip("每句字幕，与 voiceClips 一一对应（可留空则只播字幕）")]
        [TextArea] public string[] subtitleLines;
        public AudioClip[] voiceClips;

        [Header("任务绑定")]
        [Tooltip("播放完成后调用 TaskSystem.CompleteObjective 的任务 id")]
        public string taskIdToComplete = "radio_contact";

        public string InteractionPrompt =>
            _finished ? string.Empty : (_isPlaying ? "正在播放…" : "按 E 使用无线电");

        public bool CanInteract => !_isPlaying && !_finished;

        public event System.Action OnRadioStarted;
        public event System.Action OnRadioFinished;

        private AudioSource _audio;
        private bool _isPlaying;
        private bool _finished;

        void Awake()
        {
            _audio = GetComponent<AudioSource>();
            if (_audio == null) _audio = gameObject.AddComponent<AudioSource>();
            _audio.playOnAwake = false;
        }

        public void OnInteract(PlayerController player)
        {
            if (!CanInteract) return;
            StartCoroutine(PlaySequence());
        }

        IEnumerator PlaySequence()
        {
            _isPlaying = true;
            OnRadioStarted?.Invoke();

            int count = Mathf.Max(
                subtitleLines != null ? subtitleLines.Length : 0,
                voiceClips != null ? voiceClips.Length : 0);

            for (int i = 0; i < count; i++)
            {
                string line = subtitleLines != null && i < subtitleLines.Length
                    ? subtitleLines[i]
                    : string.Empty;

                if (!string.IsNullOrEmpty(line) && TaskSystem.Instance != null)
                    TaskSystem.Instance.ShowSubtitle(line);

                if (voiceClips != null && i < voiceClips.Length && voiceClips[i] != null)
                {
                    _audio.clip = voiceClips[i];
                    _audio.Play();
                    yield return new WaitForSeconds(voiceClips[i].length + 0.3f);
                }
                else
                {
                    // 无音频时按字幕长度估算停顿
                    float seconds = Mathf.Clamp(line.Length * 0.12f, 1f, 6f);
                    yield return new WaitForSeconds(seconds);
                }
            }

            if (TaskSystem.Instance != null)
            {
                TaskSystem.Instance.ShowSubtitle(string.Empty);
                if (!string.IsNullOrEmpty(taskIdToComplete))
                    TaskSystem.Instance.CompleteObjective(taskIdToComplete);
            }

            _isPlaying = false;
            _finished = true;
            OnRadioFinished?.Invoke();
        }
    }
}
