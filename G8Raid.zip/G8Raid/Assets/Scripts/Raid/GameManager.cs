using UnityEngine;
using UnityEngine.SceneManagement;
using G8Raid.Actor;

namespace G8Raid.Raid
{
    public enum GameState
    {
        Playing,
        Paused,
        Dead,
        Victory
    }

    /// <summary>
    /// 全局游戏管理器：管理游戏状态（进行/暂停/死亡/胜利），
    /// 监听玩家死亡与全部任务完成，触发对应 UI。
    /// 挂载到场景中常驻物体上（单例）。
    /// </summary>
    public class GameManager : MonoBehaviour
    {
        public static GameManager Instance { get; private set; }

        public GameState State { get; private set; } = GameState.Playing;

        [Header("结算统计")]
        public int enemiesKilled;
        public int lootCollected;
        public float sessionTime;

        [Header("场景")]
        public string mainMenuSceneName = "MainMenu";

        public event System.Action<GameState> OnStateChanged;
        public event System.Action OnGamePaused;
        public event System.Action OnGameResumed;

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }

        void Start()
        {
            if (PlayerController.Instance != null)
                PlayerController.Instance.OnPlayerDeath += HandlePlayerDeath;

            if (TaskSystem.Instance != null)
                TaskSystem.Instance.OnAllObjectivesCompleted += HandleAllObjectivesDone;
        }

        void Update()
        {
            if (State == GameState.Playing)
                sessionTime += Time.deltaTime;

            // 桌面端暂停
            if (!Application.isMobilePlatform && Input.GetKeyDown(KeyCode.Escape))
            {
                if (State == GameState.Playing) Pause();
                else if (State == GameState.Paused) Resume();
            }
        }

        public void Pause()
        {
            if (State != GameState.Playing) return;
            State = GameState.Paused;
            Time.timeScale = 0f;
            OnGamePaused?.Invoke();
            OnStateChanged?.Invoke(State);
        }

        public void Resume()
        {
            if (State != GameState.Paused) return;
            State = GameState.Playing;
            Time.timeScale = 1f;
            OnGameResumed?.Invoke();
            OnStateChanged?.Invoke(State);
        }

        void HandlePlayerDeath()
        {
            if (State != GameState.Playing) return;
            State = GameState.Dead;
            OnStateChanged?.Invoke(State);
        }

        void HandleAllObjectivesDone()
        {
            // 全部任务完成后开放撤离
            if (TaskSystem.Instance != null)
                TaskSystem.Instance.extractionAllowed = true;
        }

        /// <summary>撤离成功后调用（由 EvacuatePoint 完成 evacuate 任务后触发）。</summary>
        public void TriggerVictory()
        {
            if (State != GameState.Playing) return;
            State = GameState.Victory;
            OnStateChanged?.Invoke(State);
        }

        public void RestartLevel()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }

        public void ReturnToMainMenu()
        {
            Time.timeScale = 1f;
            SceneManager.LoadScene(mainMenuSceneName);
        }

        public void RegisterKill() => enemiesKilled++;
        public void RegisterLoot() => lootCollected++;

        void OnDestroy()
        {
            Time.timeScale = 1f;
        }
    }
}
