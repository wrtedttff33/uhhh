using System;
using System.Collections.Generic;
using UnityEngine;

namespace G8Raid.Raid
{
    /// <summary>
    /// 任务 / 目标系统：管理主线任务清单、完成状态推进，
    /// 并提供全局通知（字幕、toast）与玩法阶段开关（如是否允许撤离）。
    /// 挂载到场景中的 GameManager / 常驻物体上（单例）。
    /// </summary>
    public class TaskSystem : MonoBehaviour
    {
        public static TaskSystem Instance { get; private set; }

        [Serializable]
        public class TaskObjective
        {
            [Tooltip("唯一 id，供脚本 CompleteObjective(id) 调用")]
            public string id;
            public string title;
            [TextArea] public string description;
            [NonSerialized] public bool isCompleted;
        }

        [Header("主线任务清单（按顺序推进）")]
        public List<TaskObjective> objectives = new List<TaskObjective>();

        [Header("玩法阶段开关")]
        [Tooltip("为 true 时撤离点才允许触发撤离（防止提前过关）")]
        public bool extractionAllowed;

        /// <summary>当前未完成任务在清单中的下标。</summary>
        public int CurrentIndex { get; private set; }

        public TaskObjective Current =>
            objectives.Count > 0 && CurrentIndex >= 0 && CurrentIndex < objectives.Count
                ? objectives[CurrentIndex]
                : null;

        // —— 全局事件（UI / 音频可订阅）——
        public event Action<TaskObjective> OnObjectiveCompleted;
        public event Action OnAllObjectivesCompleted;
        public event Action<string> OnSubtitle;        // 广播/语音字幕
        public event Action<string, string> OnNotify;  // 提示（标题, 内容）

        void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;
        }

        void Start()
        {
            if (Current != null)
                Notify("当前任务", Current.title + "：" + Current.description);
        }

        /// <summary>查询某个任务是否已完成。</summary>
        public bool IsCompleted(string id)
        {
            var o = objectives.Find(x => x.id == id);
            return o != null && o.isCompleted;
        }

        /// <summary>
        /// 按 id 完成一个任务；完成后自动推进到下一个未完成任务。
        /// </summary>
        /// <returns>是否真的触发了完成（id 不存在或已完成为 false）。</returns>
        public bool CompleteObjective(string id)
        {
            var o = objectives.Find(x => x.id == id);
            if (o == null || o.isCompleted) return false;

            o.isCompleted = true;
            OnObjectiveCompleted?.Invoke(o);
            Notify("任务完成", o.title);

            while (CurrentIndex < objectives.Count && objectives[CurrentIndex].isCompleted)
                CurrentIndex++;

            if (CurrentIndex >= objectives.Count)
            {
                OnAllObjectivesCompleted?.Invoke();
                Notify("任务", "全部任务完成！");
            }
            else if (Current != null)
            {
                Notify("新任务", Current.title + "：" + Current.description);
            }
            return true;
        }

        public void ShowSubtitle(string text) => OnSubtitle?.Invoke(text);
        public void Notify(string title, string message) => OnNotify?.Invoke(title, message);
    }
}
