using System.Collections.Generic;
using System.Text;
using UnityEngine;
using G8Raid.Actor;

namespace G8Raid.Raid
{
    /// <summary>摩尔斯电码工具：字符 &lt;-&gt; 电码转换（静态工具类）。</summary>
    public static class MorseUtility
    {
        private static readonly Dictionary<char, string> ToMorse = new Dictionary<char, string>
        {
            {'A',".-"},{'B',"-..."},{'C',"-.-."},{'D',"-.."},{'E',"."},
            {'F',"..-."},{'G',"--."},{'H',"...."},{'I',".."},{'J',".---"},
            {'K',"-.-"},{'L',".-.."},{'M',"--"},{'N',"-."},{'O',"---"},
            {'P',".--."},{'Q',"--.-"},{'R',".-."},{'S',"..."},{'T',"-"},
            {'U',"..-"},{'V',"...-"},{'W',".--"},{'X',"-..-"},{'Y',"-.--"},
            {'Z',"--.."},
            {'0',"-----"},{'1',".----"},{'2',"..---"},{'3',"...--"},
            {'4',"....-"},{'5',"....."},{'6',"-...."},{'7',"--..."},
            {'8',"---.."},{'9',"----."}
        };

        private static readonly Dictionary<string, char> FromMorse = BuildReverse();

        static Dictionary<string, char> BuildReverse()
        {
            var d = new Dictionary<string, char>();
            foreach (var kv in ToMorse) d[kv.Value] = kv.Key;
            return d;
        }

        public static bool TryGetMorse(char c, out string morse) =>
            ToMorse.TryGetValue(char.ToUpperInvariant(c), out morse);

        public static bool TryDecode(string morse, out char c) =>
            FromMorse.TryGetValue(morse, out c);

        /// <summary>整句编码：字母间用空格分隔，单词间用 " / " 分隔。</summary>
        public static string Encode(string text)
        {
            var sb = new StringBuilder();
            bool first = true;
            foreach (char raw in text)
            {
                if (raw == ' ')
                {
                    sb.Append(" / ");
                    first = true;
                    continue;
                }
                if (TryGetMorse(raw, out string morse))
                {
                    if (!first) sb.Append(' ');
                    sb.Append(morse);
                    first = false;
                }
            }
            return sb.ToString();
        }

        /// <summary>整句解码（支持 " / " 与空格分隔）。</summary>
        public static string Decode(string morseSequence)
        {
            var sb = new StringBuilder();
            foreach (string word in morseSequence.Split('/'))
            {
                if (sb.Length > 0) sb.Append(' ');
                bool first = true;
                foreach (string letter in word.Trim().Split(' '))
                {
                    if (string.IsNullOrEmpty(letter)) continue;
                    if (TryDecode(letter, out char c))
                    {
                        if (!first) { /* 字母间无额外分隔 */ }
                        sb.Append(c);
                        first = false;
                    }
                }
            }
            return sb.ToString();
        }
    }

    /// <summary>
    /// 摩尔斯电码破解电脑：靠近按交互键进入输入模式，
    /// 按 E 输入点(.)、按 Q 输入划(-)、按回车提交、按退格删除。
    /// 输入整词电码正确即解锁，完成绑定任务（如"破解终端"）。
    /// 需要：Collider(Is Trigger) + 本脚本。
    /// </summary>
    public class ComputerMorse : MonoBehaviour, IInteractable
    {
        [Header("摩斯密码锁")]
        [Tooltip("目标单词，例如 HELP / OPEN / 1987")]
        public string targetWord = "HELP";
        public string taskIdToComplete = "hack_computer";

        [Header("音效（可选）")]
        public AudioClip beepDot;
        public AudioClip beepDash;
        public AudioClip successClip;
        public AudioClip failClip;

        public string InteractionPrompt => _unlocked ? "系统已解锁" : "按 E 破解密码";
        public bool CanInteract => !_unlocked && !_active;

        public event System.Action OnUnlocked;

        private readonly List<bool> _input = new List<bool>(); // false=点(.) true=划(-)
        private bool _active;
        private bool _unlocked;
        private AudioSource _audio;
        private float _inputCooldown; // 激活后延迟一帧再接受输入，避免 E 键同时触发交互和输入

        void Awake()
        {
            _audio = GetComponent<AudioSource>();
            if (_audio == null) _audio = gameObject.AddComponent<AudioSource>();
        }

        public void OnInteract(PlayerController player)
        {
            if (!CanInteract) return;
            _active = true;
            _input.Clear();
            _inputCooldown = 0.15f; // 延迟接受输入
            if (TaskSystem.Instance != null)
                TaskSystem.Instance.ShowSubtitle("输入摩斯码：按 E 输入点，按 Q 输入划，按回车提交");
        }

        void Update()
        {
            if (!_active || _unlocked) return;

            if (_inputCooldown > 0f) { _inputCooldown -= Time.deltaTime; return; }

            if (Input.GetKeyDown(KeyCode.E)) AppendSignal(false);
            else if (Input.GetKeyDown(KeyCode.Q)) AppendSignal(true);
            else if (Input.GetKeyDown(KeyCode.Return)) Submit();
            else if (Input.GetKeyDown(KeyCode.Backspace)) RemoveLast();
        }

        string EncodeCurrent()
        {
            var sb = new StringBuilder();
            foreach (bool dash in _input) sb.Append(dash ? '-' : '.');
            return sb.ToString();
        }

        void AppendSignal(bool dash)
        {
            _input.Add(dash);
            PlayBeep(dash ? beepDash : beepDot);
            if (TaskSystem.Instance != null)
                TaskSystem.Instance.ShowSubtitle(EncodeCurrent());
        }

        void RemoveLast()
        {
            if (_input.Count == 0) return;
            _input.RemoveAt(_input.Count - 1);
            if (TaskSystem.Instance != null)
                TaskSystem.Instance.ShowSubtitle(EncodeCurrent());
        }

        void Submit()
        {
            string entered = EncodeCurrent();
            _active = false;

            string expected = MorseUtility.Encode(targetWord).Replace(" ", string.Empty);
            if (entered.Equals(expected, System.StringComparison.OrdinalIgnoreCase))
            {
                Unlock();
            }
            else
            {
                Play(failClip);
                if (TaskSystem.Instance != null)
                {
                    TaskSystem.Instance.ShowSubtitle("密码错误，请重试");
                    TaskSystem.Instance.Notify("终端", "摩斯密码输入错误");
                }
                _input.Clear();
            }
        }

        void Unlock()
        {
            _unlocked = true;
            Play(successClip);
            if (TaskSystem.Instance != null)
            {
                TaskSystem.Instance.ShowSubtitle(string.Empty);
                TaskSystem.Instance.Notify("终端", "解锁成功：" + targetWord);
                if (!string.IsNullOrEmpty(taskIdToComplete))
                    TaskSystem.Instance.CompleteObjective(taskIdToComplete);
            }
            OnUnlocked?.Invoke();
        }

        void PlayBeep(AudioClip clip) => Play(clip);

        void Play(AudioClip clip)
        {
            if (clip == null) return;
            _audio.PlayOneShot(clip);
        }
    }
}
