# Prefabs 接线说明

本目录下 `.prefab` 为**空物体占位**（保证目录结构完整、Unity 可正常导入）。
请在 Unity Editor 中完成模型与脚本装配，参考下表：

| 预制体 | 脚本 | 必需组件 |
|---|---|---|
| Radio.prefab | RadioInteract | Box Collider(Is Trigger) + 电台模型 + 可选 AudioSource |
| Computer.prefab | ComputerMorse | Box Collider(Is Trigger) + 电脑模型 |
| EvacPoint.prefab | EvacuatePoint | Collider(Is Trigger) + 撤离标记物（建议加 MapMarker） |
| EliteEnemy.prefab | EnemyEliteAI | Capsule Collider + Rigidbody + 可选 NavMeshAgent |
| AITeammate.prefab | AITeammate | Capsule Collider + 可选 CharacterController |

`LootContainers/` 下放置各类战利品容器预制体（Crate / Chest / SupplyCache），
挂 LootContainer，模型带 Animator 时触发参数为 `Open`。

通用约定：玩家物体 Tag = `Player`；精英敌人需烘焙 NavMesh 才有寻路。
