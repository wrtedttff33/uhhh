using System.Collections.Generic;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using G8Raid.Actor;
using G8Raid.Inventory;
using G8Raid.Loot;
using G8Raid.Mobile;
using G8Raid.Raid;
using G8Raid.UI;
using G8Raid.Vehicle;
using G8Raid.Weapon;

namespace G8Raid.EditorTools
{
    /// <summary>
    /// 一键生成完整可玩场景的编辑器工具。
    /// 在 Unity 菜单栏点击「G8Raid → 一键生成完整游戏场景」，
    /// 或云端 CI 执行：Unity -batchmode -executeMethod G8Raid.EditorTools.GameSceneBuilder.BuildFullScene
    /// 全程无需手动搭建，自动生成：玩家/敌人/AI队友/交互物/波次防守/完整UI/移动端触控。
    /// </summary>
    public static class GameSceneBuilder
    {
        const string ScenePath = "Assets/Scenes/Raid.unity";
        const string EnemyPrefabPath = "Assets/Prefabs/Enemy.prefab";
        const string TeammatePrefabPath = "Assets/Prefabs/Teammate.prefab";
        const string LootBoxPrefabPath = "Assets/Prefabs/LootContainer.prefab";
        const string PickupPrefabPath = "Assets/Prefabs/LootPickup.prefab";
        const string VehiclePrefabPath = "Assets/Prefabs/Vehicle.prefab";
        const string WeaponPath = "Assets/Resources/Weapons/AssaultRifle.asset";
        const string LootDataPath = "Assets/Resources/LootData/";

        static Font _font;
        static Sprite _whiteSprite;
        static Material _groundMat, _playerMat, _enemyMat, _teammateMat, _lootMat, _radioMat, _computerMat, _evacMat, _vehicleMat;

        [MenuItem("G8Raid/一键生成完整游戏场景")]
        public static void BuildFullScene() => Build();

        // ====================================================================
        // 主流程
        // ====================================================================
        static void Build()
        {
            EnsureFolders();
            CreateSharedAssets();
            CreateRuntimeAssets();

            // 创建场景
            var scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
            EnsureLighting(scene);
            var player = CreatePlayer();
            var enemyPrefab = CreateEnemyPrefab();
            var teammatePrefab = CreateTeammatePrefab();
            var pickupPrefab = CreatePickupPrefab();
            var lootBoxPrefab = CreateLootBoxPrefab();
            var vehiclePrefab = CreateVehiclePrefab();
            var gameManager = CreateGameManager(enemyPrefab, pickupPrefab);
            CreateWorld(player, enemyPrefab, teammatePrefab, lootBoxPrefab, vehiclePrefab, gameManager);
            CreateUICanvas(pickupPrefab, vehiclePrefab, teammatePrefab);

            // 保存
            EditorSceneManager.SaveScene(scene, ScenePath);
            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };

            Debug.Log("[G8Raid] 完整游戏场景已生成: " + ScenePath);
        }

        static void EnsureFolders()
        {
            EnsureFolder("Assets/Scenes");
            EnsureFolder("Assets/Resources");
            EnsureFolder("Assets/Resources/Weapons");
            EnsureFolder("Assets/Resources/LootData");
        }

        static void EnsureFolder(string path)
        {
            if (!AssetDatabase.IsValidFolder(path))
            {
                string parent = path.Substring(0, path.LastIndexOf('/'));
                string name = path.Substring(path.LastIndexOf('/') + 1);
                if (!AssetDatabase.IsValidFolder(parent)) EnsureFolder(parent);
                AssetDatabase.CreateFolder(parent, name);
            }
        }

        // ====================================================================
        // 共享资产（材质 / 字体 / 白图）
        // ====================================================================
        static void CreateSharedAssets()
        {
            _font = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");
            if (_font == null) _font = Resources.GetBuiltinResource<Font>("Arial.ttf");

            var tex = new Texture2D(4, 4, TextureFormat.RGBA32, false);
            var pixels = new Color[16];
            for (int i = 0; i < 16; i++) pixels[i] = Color.white;
            tex.SetPixels(pixels);
            tex.Apply();
            _whiteSprite = Sprite.Create(tex, new Rect(0, 0, 4, 4), new Vector2(0.5f, 0.5f));

            _groundMat = MakeMat("G8Raid-Ground", new Color(0.35f, 0.45f, 0.35f));
            _playerMat = MakeMat("G8Raid-Player", new Color(0.3f, 0.55f, 0.9f));
            _enemyMat = MakeMat("G8Raid-Enemy", new Color(0.75f, 0.2f, 0.2f));
            _teammateMat = MakeMat("G8Raid-Teammate", new Color(0.2f, 0.75f, 0.35f));
            _lootMat = MakeMat("G8Raid-Loot", new Color(0.9f, 0.75f, 0.3f));
            _radioMat = MakeMat("G8Raid-Radio", new Color(0.3f, 0.3f, 0.3f));
            _computerMat = MakeMat("G8Raid-Computer", new Color(0.4f, 0.4f, 0.5f));
            _evacMat = MakeMat("G8Raid-Evac", new Color(0.9f, 0.9f, 0.2f));
            _vehicleMat = MakeMat("G8Raid-Vehicle", new Color(0.5f, 0.4f, 0.25f));
        }

        static Material MakeMat(string name, Color color)
        {
            var mat = new Material(Shader.Find("Standard"));
            mat.color = color;
            AssetDatabase.CreateAsset(mat, "Assets/Materials/" + name + ".mat");
            return mat;
        }

        // ====================================================================
        // 运行时数据资产（武器 / 战利品）
        // ====================================================================
        static void CreateRuntimeAssets()
        {
            var weapon = AssetDatabase.LoadAssetAtPath<WeaponData>(WeaponPath);
            if (weapon == null)
            {
                weapon = ScriptableObject.CreateInstance<WeaponData>();
                weapon.weaponName = "突击步枪";
                weapon.fireMode = FireMode.Automatic;
                weapon.damage = 25f;
                weapon.roundsPerMinute = 600f;
                weapon.range = 80f;
                weapon.magSize = 30;
                weapon.reloadTime = 2.2f;
                weapon.spreadIdle = 0.8f;
                weapon.spreadMoving = 2.5f;
                weapon.spreadPerShot = 0.15f;
                weapon.spreadRecover = 3f;
                AssetDatabase.CreateAsset(weapon, WeaponPath);
            }

            CreateLootData("医疗包", LootRarity.Uncommon, 30);
            CreateLootData("弹药箱", LootRarity.Common, 15);
            CreateLootData("旧芯片", LootRarity.Rare, 60);
            CreateLootData("黄金徽章", LootRarity.Legendary, 300);
        }

        static void CreateLootData(string name, LootRarity rarity, int value)
        {
            string path = LootDataPath + name + ".asset";
            if (AssetDatabase.LoadAssetAtPath<LootItemData>(path) != null) return;
            var data = ScriptableObject.CreateInstance<LootItemData>();
            data.displayName = name;
            data.rarity = rarity;
            data.value = value;
            data.description = name;
            AssetDatabase.CreateAsset(data, path);
        }

        // ====================================================================
        // 玩家
        // ====================================================================
        static GameObject CreatePlayer()
        {
            var player = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            player.name = "Player";
            player.tag = "Player";
            player.transform.position = new Vector3(0f, 1f, -8f);
            player.GetComponent<Renderer>().sharedMaterial = _playerMat;
            Object.DestroyImmediate(player.GetComponent<Collider>());

            var cc = player.AddComponent<CharacterController>();
            cc.height = 2f;
            cc.radius = 0.4f;
            cc.center = new Vector3(0f, 1f, 0f);

            var pc = player.AddComponent<PlayerController>();
            player.AddComponent<WeaponSystem>();
            player.AddComponent<InventorySystem>();

            // 相机结构：Player → CameraPivot → Main Camera
            var pivot = new GameObject("CameraPivot");
            pivot.transform.SetParent(player.transform, false);
            pivot.transform.localPosition = new Vector3(0f, 1.7f, 0f);

            var camGo = new GameObject("Main Camera");
            camGo.tag = "MainCamera";
            camGo.transform.SetParent(pivot.transform, false);
            camGo.transform.localPosition = Vector3.zero;
            var cam = camGo.AddComponent<Camera>();
            cam.fieldOfView = 70f;
            cam.nearClipPlane = 0.05f;
            camGo.AddComponent<AudioListener>();

            var muzzle = new GameObject("Muzzle");
            muzzle.transform.SetParent(camGo.transform, false);
            muzzle.transform.localPosition = new Vector3(0.3f, -0.25f, 0.8f);

            pc.cameraPivot = pivot.transform;
            pc.playerCamera = cam;

            var ws = player.GetComponent<WeaponSystem>();
            ws.currentWeapon = AssetDatabase.LoadAssetAtPath<WeaponData>(WeaponPath);
            ws.playerCamera = cam;
            ws.muzzle = muzzle.transform;

            return player;
        }

        // ====================================================================
        // 敌人预制体
        // ====================================================================
        static GameObject CreateEnemyPrefab()
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            go.name = "Enemy";
            go.GetComponent<Renderer>().sharedMaterial = _enemyMat;
            var col = go.GetComponent<Collider>() as CapsuleCollider;
            col.height = 2f;
            col.radius = 0.5f;
            col.center = new Vector3(0f, 1f, 0f);

            var rb = go.AddComponent<Rigidbody>();
            rb.useGravity = true;
            rb.constraints = RigidbodyConstraints.FreezeRotation;

            var ai = go.AddComponent<EnemyEliteAI>();
            ai.maxHealth = 180f;
            ai.moveSpeed = 3.5f;
            ai.attackDamage = 20f;
            ai.hasEliteSkill = true;

            return SavePrefab(go, EnemyPrefabPath);
        }

        // ====================================================================
        // AI 队友预制体
        // ====================================================================
        static GameObject CreateTeammatePrefab()
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            go.name = "Teammate";
            go.GetComponent<Renderer>().sharedMaterial = _teammateMat;
            var col = go.GetComponent<Collider>() as CapsuleCollider;
            col.height = 2f;
            col.radius = 0.4f;
            col.center = new Vector3(0f, 1f, 0f);
            go.AddComponent<AITeammate>();
            return SavePrefab(go, TeammatePrefabPath);
        }

        // ====================================================================
        // 战利品箱预制体
        // ====================================================================
        static GameObject CreateLootBoxPrefab()
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "LootContainer";
            go.transform.localScale = new Vector3(1f, 0.8f, 1f);
            go.GetComponent<Renderer>().sharedMaterial = _lootMat;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            var col = go.AddComponent<BoxCollider>();
            col.isTrigger = true;

            var loot = go.AddComponent<LootContainer>();
            loot.containerType = LootContainerType.Crate;
            loot.randomDropCount = 2;
            loot.dropPickupPrefab = true;
            loot.pickupPrefab = AssetDatabase.LoadAssetAtPath<GameObject>(PickupPrefabPath);
            loot.guaranteedDrops = new List<LootItemData>
            {
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "医疗包.asset"),
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "旧芯片.asset")
            };
            loot.possibleRandomDrops = new[]
            {
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "弹药箱.asset"),
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "黄金徽章.asset")
            };
            return SavePrefab(go, LootBoxPrefabPath);
        }

        // ====================================================================
        // 拾取物预制体（敌人掉落 / 箱子生成）
        // ====================================================================
        static GameObject CreatePickupPrefab()
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name = "LootPickup";
            go.transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
            go.GetComponent<Renderer>().sharedMaterial = _lootMat;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            var col = go.AddComponent<SphereCollider>();
            col.isTrigger = true;
            col.radius = 1f;
            go.AddComponent<LootItem>();
            return SavePrefab(go, PickupPrefabPath);
        }

        // ====================================================================
        // 载具预制体
        // ====================================================================
        static GameObject CreateVehiclePrefab()
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "Vehicle";
            go.transform.localScale = new Vector3(2f, 1f, 3.5f);
            go.GetComponent<Renderer>().sharedMaterial = _vehicleMat;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            var col = go.AddComponent<BoxCollider>();
            col.center = new Vector3(0f, 0.5f, 0f);

            var rb = go.AddComponent<Rigidbody>();
            rb.mass = 800f;

            var vc = go.AddComponent<VehicleController>();
            vc.enginePower = 1500f;
            vc.maxSpeed = 40f;
            vc.fuelConsumePerSec = 0.5f;

            var mount = new GameObject("CameraMount");
            mount.transform.SetParent(go.transform, false);
            mount.transform.localPosition = new Vector3(0f, 1.6f, -1.2f);
            vc.cameraMount = mount.transform;

            return SavePrefab(go, VehiclePrefabPath);
        }

        static GameObject SavePrefab(GameObject go, string path)
        {
            var prefab = PrefabUtility.SaveAsPrefabAsset(go, path);
            Object.DestroyImmediate(go);
            return prefab;
        }

        // ====================================================================
        // 游戏管理器（任务 / 状态 / 掉落）
        // ====================================================================
        static GameObject CreateGameManager(GameObject enemyPrefab, GameObject pickupPrefab)
        {
            var gm = new GameObject("GameManager");

            var task = gm.AddComponent<TaskSystem>();
            task.objectives = new List<TaskSystem.TaskObjective>
            {
                new TaskSystem.TaskObjective { id = "radio_contact", title = "联络指挥部", description = "前往无线电处，按 E 与指挥部联络" },
                new TaskSystem.TaskObjective { id = "hack_computer", title = "破解终端", description = "在电脑上输入摩斯密码（HELP）" },
                new TaskSystem.TaskObjective { id = "defend_area", title = "守住据点", description = "击退所有来袭的敌人" },
                new TaskSystem.TaskObjective { id = "evacuate", title = "撤离", description = "前往撤离点，停留 5 秒完成撤离" }
            };

            var mgr = gm.AddComponent<GameManager>();

            var drops = gm.AddComponent<EnemyDropManager>();
            drops.ammoPickupPrefab = pickupPrefab;
            drops.dropChance = 0.5f;
            drops.randomDrops = new[]
            {
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "医疗包.asset"),
                AssetDatabase.LoadAssetAtPath<LootItemData>(LootDataPath + "旧芯片.asset")
            };

            return gm;
        }

        // ====================================================================
        // 世界物体（地形 / 交互物 / 波次 / 标记）
        // ====================================================================
        static void CreateWorld(GameObject player, GameObject enemyPrefab, GameObject teammatePrefab,
                                GameObject lootBoxPrefab, GameObject vehiclePrefab, GameObject gameManager)
        {
            // 地面
            var ground = GameObject.CreatePrimitive(PrimitiveType.Plane);
            ground.name = "Ground";
            ground.transform.localScale = new Vector3(20f, 1f, 20f);
            ground.GetComponent<Renderer>().sharedMaterial = _groundMat;

            // 简易建筑墙（掩体）
            for (int i = 0; i < 6; i++)
            {
                var wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
                wall.name = "Wall";
                wall.transform.position = new Vector3(Random.Range(-12f, 12f), 1.5f, Random.Range(-12f, 12f));
                wall.transform.localScale = new Vector3(Random.Range(3f, 6f), 3f, 0.5f);
                wall.transform.rotation = Quaternion.Euler(0f, Random.Range(0f, 360f), 0f);
                wall.GetComponent<Renderer>().sharedMaterial = _groundMat;
            }

            // 灯光
            var light = new GameObject("Directional Light");
            var l = light.AddComponent<Light>();
            l.type = LightType.Directional;
            l.intensity = 1f;
            light.transform.rotation = Quaternion.Euler(50f, -30f, 0f);

            // 无线电（起点剧情）
            var radio = CreateInteractible("Radio", PrimitiveType.Cube, _radioMat, new Vector3(2f, 1f, -6f));
            var radioScript = radio.AddComponent<RadioInteract>();
            radioScript.radioName = "便携无线电";
            radioScript.subtitleLines = new[]
            {
                "指挥部：侦察队，收到信号了吗？",
                "指挥部：据报基地东侧出现大量武装目标，请立刻行动。",
                "指挥部：先去东侧仓库破解终端获取情报，完毕。"
            };
            radioScript.taskIdToComplete = "radio_contact";
            radio.AddComponent<MapMarker>().markerType = MarkerType.Objective;
            radio.GetComponent<MapMarker>().label = "无线电";

            // 电脑（摩斯破解）
            var computer = CreateInteractible("Computer", PrimitiveType.Cube, _computerMat, new Vector3(6f, 1.2f, -4f));
            computer.transform.localScale = new Vector3(1.2f, 0.8f, 0.8f);
            var computerScript = computer.AddComponent<ComputerMorse>();
            computerScript.targetWord = "HELP";
            computerScript.taskIdToComplete = "hack_computer";
            computer.AddComponent<MapMarker>().markerType = MarkerType.Objective;
            computer.GetComponent<MapMarker>().label = "终端";

            // 撤离点（基地西侧）
            var evac = CreateInteractible("EvacPoint", PrimitiveType.Cylinder, _evacMat, new Vector3(-14f, 0.5f, 10f));
            evac.transform.localScale = new Vector3(2f, 0.5f, 2f);
            var evacScript = evac.AddComponent<EvacuatePoint>();
            evacScript.requiredStay = 5f;
            evacScript.taskIdOnComplete = "evacuate";
            evac.AddComponent<MapMarker>().markerType = MarkerType.Evacuation;
            evac.GetComponent<MapMarker>().label = "撤离点";

            // AI 队友
            var mate = (GameObject)PrefabUtility.InstantiatePrefab(teammatePrefab);
            mate.name = "Teammate";
            mate.transform.position = new Vector3(1f, 1f, -7f);
            mate.AddComponent<MapMarker>().markerType = MarkerType.Ally;
            mate.GetComponent<MapMarker>().label = "队友";

            // 战利品箱 × 3
            SpawnBox(lootBoxPrefab, new Vector3(8f, 0.5f, 2f));
            SpawnBox(lootBoxPrefab, new Vector3(-6f, 0.5f, -2f));
            SpawnBox(lootBoxPrefab, new Vector3(0f, 0.5f, 6f));

            // 载具
            var vehicle = (GameObject)PrefabUtility.InstantiatePrefab(vehiclePrefab);
            vehicle.name = "Vehicle";
            vehicle.transform.position = new Vector3(3f, 0f, 3f);
            vehicle.transform.rotation = Quaternion.Euler(0f, 90f, 0f);
            vehicle.AddComponent<MapMarker>().markerType = MarkerType.Vehicle;
            vehicle.GetComponent<MapMarker>().label = "载具";

            // 波次防守（配置 2 波敌人，刷新点在撤离点附近）
            var defendGo = new GameObject("DefendWave");
            defendGo.transform.position = new Vector3(-8f, 1f, 4f);
            var defend = defendGo.AddComponent<DefendWave>();
            defend.enemyPrefab = enemyPrefab.GetComponent<EnemyEliteAI>();
            defend.autoStart = true;
            defend.startDelay = 1f;
            defend.taskIdOnCleared = "defend_area";

            var spawnPoints = new[]
            {
                MakePoint("Spawn1", new Vector3(-2f, 1f, 12f)),
                MakePoint("Spawn2", new Vector3(-12f, 1f, 8f)),
                MakePoint("Spawn3", new Vector3(-8f, 1f, 14f))
            };
            defend.waves = new[]
            {
                new DefendWave.WaveConfig { name = "波次 1", enemyPrefab = defend.enemyPrefab, count = 3, spawnInterval = 1.2f, spawnPoints = spawnPoints },
                new DefendWave.WaveConfig { name = "波次 2", enemyPrefab = defend.enemyPrefab, count = 4, spawnInterval = 1.0f, spawnPoints = spawnPoints }
            };
        }

        static GameObject CreateInteractible(string name, PrimitiveType type, Material mat, Vector3 pos)
        {
            var go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.position = pos;
            go.GetComponent<Renderer>().sharedMaterial = mat;
            Object.DestroyImmediate(go.GetComponent<Collider>());
            var col = go.AddComponent<BoxCollider>();
            col.isTrigger = true;
            return go;
        }

        static GameObject MakePoint(string name, Vector3 pos)
        {
            var go = new GameObject(name);
            go.transform.position = pos;
            return go;
        }

        static void SpawnBox(GameObject prefab, Vector3 pos)
        {
            var box = (GameObject)PrefabUtility.InstantiatePrefab(prefab);
            box.name = "LootContainer";
            box.transform.position = pos;
            box.AddComponent<MapMarker>().markerType = MarkerType.Loot;
            box.GetComponent<MapMarker>().label = "战利品";
        }

        static void EnsureLighting(UnityEditor.SceneManagement.Scene scene)
        {
            RenderSettings.ambientMode = UnityEngine.Rendering.AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.5f, 0.55f, 0.6f);
        }

        // ====================================================================
        // UI Canvas（完整 HUD + 结算面板 + 移动端触控）
        // ====================================================================
        static void CreateUICanvas(GameObject pickupPrefab, GameObject vehiclePrefab, GameObject teammatePrefab)
        {
            // EventSystem
            var es = new GameObject("EventSystem");
            es.AddComponent<EventSystem>();
            es.AddComponent<StandaloneInputModule>();

            // Canvas
            var canvasGo = new GameObject("HUD");
            canvasGo.AddComponent<Canvas>().renderMode = RenderMode.ScreenSpaceOverlay;
            var scaler = canvasGo.AddComponent<CanvasScaler>();
            scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            scaler.referenceResolution = new Vector2(1920f, 1080f);
            scaler.matchWidthOrHeight = 0.5f;
            canvasGo.AddComponent<GraphicRaycaster>();
            var root = canvasGo.transform;

            // —— HUD 子元素 ——
            var healthBar = MakeHealthBar(root);
            var ammoCounter = MakeAmmoCounter(root);
            var crosshair = MakeCrosshair(root);
            var interactPrompt = MakeInteractionPrompt(root);
            var missionTracker = MakeMissionTracker(root);
            var subtitle = MakeSubtitle(root);
            var notify = MakeNotify(root);
            var lootToast = MakeLootToast(root);
            var vignette = MakeVignette(root);
            var extraction = MakeExtractionProgress(root);
            var gameOver = MakeGameOverPanel(root);
            var victory = MakeVictoryPanel(root);
            var pause = MakePausePanel(root);

            var hud = canvasGo.AddComponent<HUDController>();
            hud.healthBar = healthBar;
            hud.ammoCounter = ammoCounter;
            hud.crosshair = crosshair;
            hud.interactPrompt = interactPrompt;
            hud.missionTracker = missionTracker;
            hud.subtitle = subtitle;
            hud.notifyUI = notify;
            hud.lootToast = lootToast;
            hud.damageVignette = vignette;
            hud.extractionProgress = extraction;

            // —— 移动端触控 ——
            MakeMobileControls(root, pickupPrefab, vehiclePrefab, teammatePrefab);

            // —— 小地图 ——
            MakeMinimap(root);
        }

        static RectTransform MakeUI(string name, Transform parent, Vector2 pos, Vector2 size,
                                    TextAnchor anchor = TextAnchor.MiddleCenter, Vector2? pivot = null)
        {
            var go = new GameObject(name, typeof(RectTransform));
            var rt = (RectTransform)go.transform;
            rt.SetParent(parent, false);
            rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
            rt.pivot = pivot ?? new Vector2(0.5f, 0.5f);
            rt.anchoredPosition = pos;
            rt.sizeDelta = size;
            return rt;
        }

        static Image MakeImage(Transform parent, string name, Vector2 pos, Vector2 size, Color color)
        {
            var rt = MakeUI(name, parent, pos, size);
            var img = rt.gameObject.AddComponent<Image>();
            img.sprite = _whiteSprite;
            img.color = color;
            return img;
        }

        static Text MakeText(Transform parent, string name, Vector2 pos, Vector2 size, string content,
                             int fontSize = 24, Color? color = null, TextAnchor align = TextAnchor.MiddleLeft)
        {
            var rt = MakeUI(name, parent, pos, size, align);
            var txt = rt.gameObject.AddComponent<Text>();
            txt.font = _font;
            txt.text = content;
            txt.fontSize = fontSize;
            txt.color = color ?? Color.white;
            txt.alignment = align;
            txt.horizontalOverflow = HorizontalWrapMode.Overflow;
            txt.verticalOverflow = VerticalWrapMode.Overflow;
            return txt;
        }

        // —— 血条 ——
        static HealthBarUI MakeHealthBar(Transform root)
        {
            var panel = MakeImage(root, "HealthBar", new Vector2(-760f, -470f), new Vector2(420f, 36f),
                                  new Color(0f, 0f, 0f, 0.6f));
            var fill = MakeImage(panel.transform, "Fill", new Vector2(0f, 0f), new Vector2(416f, 32f), Color.red);
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillAmount = 1f;
            var txt = MakeText(panel.transform, "Value", new Vector2(0f, 0f), new Vector2(416f, 32f), "100 / 100", 22,
                               Color.white, TextAnchor.MiddleCenter);
            var ui = panel.gameObject.AddComponent<HealthBarUI>();
            ui.fillImage = fill;
            ui.healthText = txt;
            return ui;
        }

        // —— 弹药 ——
        static AmmoCounterUI MakeAmmoCounter(Transform root)
        {
            var txt = MakeText(root, "Ammo", new Vector2(760f, -430f), new Vector2(200f, 50f), "30 / 120", 34,
                               Color.white, TextAnchor.MiddleRight);
            var reload = MakeText(root, "Reloading", new Vector2(760f, -490f), new Vector2(200f, 30f), "换弹中...", 22,
                                  Color.yellow, TextAnchor.MiddleRight);
            reload.gameObject.SetActive(false);
            var ui = txt.gameObject.AddComponent<AmmoCounterUI>();
            ui.ammoText = txt;
            ui.reloadText = reload;
            return ui;
        }

        // —— 准星 ——
        static CrosshairUI MakeCrosshair(Transform root)
        {
            var img = MakeImage(root, "Crosshair", new Vector2(0f, 0f), new Vector2(24f, 24f),
                                new Color(1f, 1f, 1f, 0.9f));
            var ui = img.gameObject.AddComponent<CrosshairUI>();
            ui.crosshair = (RectTransform)img.transform;
            return ui;
        }

        // —— 交互提示 ——
        static InteractionPromptUI MakeInteractionPrompt(Transform root)
        {
            var bg = MakeImage(root, "InteractBg", new Vector2(0f, -90f), new Vector2(480f, 48f),
                               new Color(0f, 0f, 0f, 0.6f));
            bg.gameObject.SetActive(false);
            var txt = MakeText(bg.transform, "InteractText", new Vector2(0f, 0f), new Vector2(460f, 40f), "", 26,
                               Color.white, TextAnchor.MiddleCenter);
            var ui = bg.gameObject.AddComponent<InteractionPromptUI>();
            ui.background = bg.gameObject;
            ui.promptText = txt;
            return ui;
        }

        // —— 任务追踪 ——
        static MissionTrackerUI MakeMissionTracker(Transform root)
        {
            var title = MakeText(root, "MissionTitle", new Vector2(-760f, 400f), new Vector2(600f, 40f), "任务", 32,
                                 Color.white, TextAnchor.MiddleLeft);
            var desc = MakeText(root, "MissionDesc", new Vector2(-760f, 360f), new Vector2(700f, 30f), "", 22,
                                new Color(1f, 1f, 1f, 0.85f), TextAnchor.MiddleLeft);
            var ui = title.gameObject.AddComponent<MissionTrackerUI>();
            ui.titleText = title;
            ui.descText = desc;
            return ui;
        }

        // —— 字幕 ——
        static SubtitleUI MakeSubtitle(Transform root)
        {
            var bg = MakeImage(root, "SubtitleBg", new Vector2(0f, -430f), new Vector2(1100f, 60f),
                               new Color(0f, 0f, 0f, 0.5f));
            bg.gameObject.SetActive(false);
            var txt = MakeText(bg.transform, "SubtitleText", new Vector2(0f, 0f), new Vector2(1060f, 50f), "", 28,
                               Color.white, TextAnchor.MiddleCenter);
            var ui = bg.gameObject.AddComponent<SubtitleUI>();
            ui.background = bg.gameObject;
            ui.subtitleText = txt;
            return ui;
        }

        // —— 通知 ——
        static NotifyUI MakeNotify(Transform root)
        {
            var title = MakeText(root, "NotifyTitle", new Vector2(760f, 420f), new Vector2(500f, 36f), "", 30,
                                 Color.yellow, TextAnchor.MiddleRight);
            var msg = MakeText(root, "NotifyMsg", new Vector2(760f, 380f), new Vector2(500f, 30f), "", 22,
                               Color.white, TextAnchor.MiddleRight);
            title.gameObject.SetActive(false);
            msg.gameObject.SetActive(false);
            var ui = title.gameObject.AddComponent<NotifyUI>();
            ui.titleText = title;
            ui.messageText = msg;
            return ui;
        }

        // —— 拾取提示 ——
        static LootToastUI MakeLootToast(Transform root)
        {
            var txt = MakeText(root, "LootToast", new Vector2(-600f, -380f), new Vector2(400f, 36f), "", 24,
                               new Color(0.9f, 0.9f, 0.4f), TextAnchor.MiddleLeft);
            txt.gameObject.SetActive(false);
            var ui = txt.gameObject.AddComponent<LootToastUI>();
            ui.toastText = txt;
            return ui;
        }

        // —— 受伤红晕 ——
        static DamageVignetteUI MakeVignette(Transform root)
        {
            var img = MakeImage(root, "DamageVignette", new Vector2(0f, 0f), new Vector2(1920f, 1080f),
                                new Color(0.8f, 0f, 0f, 0f));
            img.raycastTarget = false;
            var ui = img.gameObject.AddComponent<DamageVignetteUI>();
            ui.vignetteImage = img;
            return ui;
        }

        // —— 撤离进度 ——
        static ExtractionProgressUI MakeExtractionProgress(Transform root)
        {
            var panel = MakeImage(root, "ExtractionPanel", new Vector2(0f, 180f), new Vector2(500f, 60f),
                                  new Color(0f, 0f, 0f, 0.7f));
            var fill = MakeImage(panel.transform, "ExtractionFill", new Vector2(0f, 0f), new Vector2(496f, 54f),
                                 new Color(0.2f, 0.9f, 0.4f));
            fill.type = Image.Type.Filled;
            fill.fillMethod = Image.FillMethod.Horizontal;
            fill.fillAmount = 0f;
            var txt = MakeText(panel.transform, "ExtractionText", new Vector2(0f, 0f), new Vector2(496f, 54f),
                               "正在撤离...", 26, Color.white, TextAnchor.MiddleCenter);
            var ui = panel.gameObject.AddComponent<ExtractionProgressUI>();
            ui.panel = panel.gameObject;
            ui.fillImage = fill;
            ui.statusText = txt;
            panel.gameObject.SetActive(false);
            return ui;
        }

        // —— 结算面板公共部分 ——
        static GameObject MakePanelBase(Transform root, string name, string title, Color bg)
        {
            var panel = MakeImage(root, name, new Vector2(0f, 0f), new Vector2(1920f, 1080f), bg);
            var box = MakeImage(panel.transform, "Box", new Vector2(0f, 0f), new Vector2(600f, 500f),
                                new Color(0.1f, 0.1f, 0.12f, 0.95f));
            MakeText(box.transform, "Title", new Vector2(0f, 180f), new Vector2(560f, 60f), title, 42,
                     Color.white, TextAnchor.MiddleCenter);
            return panel.gameObject;
        }

        static Button MakeButton(Transform parent, string name, Vector2 pos, Vector2 size, string label,
                                 UnityEngine.Events.UnityAction onClick)
        {
            var img = MakeImage(parent, name, pos, size, new Color(0.2f, 0.5f, 0.9f));
            var btn = img.gameObject.AddComponent<Button>();
            btn.targetGraphic = img;
            btn.onClick.AddListener(onClick);
            MakeText(img.transform, "Label", new Vector2(0f, 0f), new Vector2(size.x, size.y), label, 26,
                     Color.white, TextAnchor.MiddleCenter);
            return btn;
        }

        // —— 死亡结算 ——
        static GameOverUI MakeGameOverPanel(Transform root)
        {
            var panelGo = MakePanelBase(root, "GameOverPanel", "你已阵亡", new Color(0f, 0f, 0f, 0.85f));
            var box = panelGo.transform.GetChild(0);
            var stats = MakeText(box, "Stats", new Vector2(0f, 60f), new Vector2(560f, 120f), "统计", 26,
                                 new Color(1f, 1f, 1f, 0.9f), TextAnchor.MiddleCenter);
            var restart = MakeButton(box, "Restart", new Vector2(0f, -60f), new Vector2(240f, 56f), "重新开始", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.RestartLevel();
            });
            var menu = MakeButton(box, "Menu", new Vector2(0f, -140f), new Vector2(240f, 56f), "返回主菜单", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.ReturnToMainMenu();
            });
            var ui = panelGo.AddComponent<GameOverUI>();
            ui.panel = panelGo;
            ui.statsText = stats;
            ui.restartButton = restart;
            ui.mainMenuButton = menu;
            panelGo.SetActive(false);
            return ui;
        }

        // —— 胜利结算 ——
        static VictoryUI MakeVictoryPanel(Transform root)
        {
            var panelGo = MakePanelBase(root, "VictoryPanel", "任务完成！", new Color(0f, 0.2f, 0f, 0.85f));
            var box = panelGo.transform.GetChild(0);
            var stats = MakeText(box, "Stats", new Vector2(0f, 60f), new Vector2(560f, 120f), "统计", 26,
                                 new Color(1f, 1f, 1f, 0.9f), TextAnchor.MiddleCenter);
            var restart = MakeButton(box, "Restart", new Vector2(0f, -60f), new Vector2(240f, 56f), "再来一局", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.RestartLevel();
            });
            var menu = MakeButton(box, "Menu", new Vector2(0f, -140f), new Vector2(240f, 56f), "返回主菜单", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.ReturnToMainMenu();
            });
            var ui = panelGo.AddComponent<VictoryUI>();
            ui.panel = panelGo;
            ui.statsText = stats;
            ui.restartButton = restart;
            ui.mainMenuButton = menu;
            panelGo.SetActive(false);
            return ui;
        }

        // —— 暂停菜单 ——
        static PauseMenuUI MakePausePanel(Transform root)
        {
            var panelGo = MakePanelBase(root, "PausePanel", "暂停", new Color(0f, 0f, 0f, 0.7f));
            var box = panelGo.transform.GetChild(0);
            var resume = MakeButton(box, "Resume", new Vector2(0f, 60f), new Vector2(240f, 56f), "继续游戏", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.Resume();
            });
            var restart = MakeButton(box, "Restart", new Vector2(0f, -20f), new Vector2(240f, 56f), "重新开始", () =>
            {
                if (GameManager.Instance != null) { GameManager.Instance.Resume(); GameManager.Instance.RestartLevel(); }
            });
            var menu = MakeButton(box, "Menu", new Vector2(0f, -100f), new Vector2(240f, 56f), "返回主菜单", () =>
            {
                if (GameManager.Instance != null) GameManager.Instance.ReturnToMainMenu();
            });
            var ui = panelGo.AddComponent<PauseMenuUI>();
            ui.panel = panelGo;
            ui.resumeButton = resume;
            ui.restartButton = restart;
            ui.quitButton = menu;
            panelGo.SetActive(false);
            return ui;
        }

        // ====================================================================
        // 移动端触控 UI
        // ====================================================================
        static void MakeMobileControls(Transform root, GameObject pickupPrefab, GameObject vehiclePrefab, GameObject teammatePrefab)
        {
            // 左下虚拟摇杆
            var joyBg = MakeImage(root, "Joystick", new Vector2(-380f, -320f), new Vector2(200f, 200f),
                                  new Color(1f, 1f, 1f, 0.15f));
            joyBg.raycastTarget = true;
            var joyHandle = MakeImage(joyBg.transform, "JoystickHandle", new Vector2(0f, 0f), new Vector2(90f, 90f),
                                      new Color(1f, 1f, 1f, 0.5f));
            joyHandle.raycastTarget = false;
            var joy = joyBg.gameObject.AddComponent<VirtualJoystick>();
            joy.background = joyBg;
            joy.handle = joyHandle;
            joy.radius = 100f;

            // 右侧视角区域（透明全屏覆盖，放在摇杆下层）
            var look = MakeImage(root, "LookArea", new Vector2(480f, 0f), new Vector2(1440f, 1080f),
                                 new Color(1f, 1f, 1f, 0f));
            look.raycastTarget = true;
            var touchLook = look.gameObject.AddComponent<TouchLookArea>();
            touchLook.sensitivity = 0.15f;

            // 右下开火按钮
            var fire = MakeImage(root, "FireButton", new Vector2(740f, -280f), new Vector2(140f, 140f),
                                 new Color(1f, 0.3f, 0.3f, 0.4f));
            var fireBtn = fire.gameObject.AddComponent<MobileButton>();

            // 换弹
            var reload = MakeImage(root, "ReloadButton", new Vector2(830f, -150f), new Vector2(80f, 80f),
                                   new Color(0.3f, 0.4f, 0.8f, 0.4f));
            reload.gameObject.AddComponent<MobileButton>();

            // 交互
            var interact = MakeImage(root, "InteractButton", new Vector2(830f, -400f), new Vector2(90f, 90f),
                                     new Color(0.4f, 0.8f, 0.4f, 0.4f));
            interact.gameObject.AddComponent<MobileButton>();

            // 跳跃
            var jump = MakeImage(root, "JumpButton", new Vector2(560f, -300f), new Vector2(90f, 90f),
                                  new Color(0.5f, 0.5f, 0.7f, 0.4f));
            jump.gameObject.AddComponent<MobileButton>();

            // 疾跑（按住）
            var sprint = MakeImage(root, "SprintButton", new Vector2(400f, -200f), new Vector2(80f, 80f),
                                   new Color(0.7f, 0.7f, 0.3f, 0.4f));
            sprint.gameObject.AddComponent<MobileButton>();

            // 医疗包
            var medkit = MakeImage(root, "MedkitButton", new Vector2(320f, -360f), new Vector2(80f, 80f),
                                   new Color(0.8f, 0.3f, 0.3f, 0.5f));
            medkit.gameObject.AddComponent<MobileButton>();

            // 按钮文字
            MakeText(fire.transform, "FireLabel", new Vector2(0f, 0f), new Vector2(140f, 40f), "射击", 28,
                     Color.white, TextAnchor.MiddleCenter);
            MakeText(reload.transform, "ReloadLabel", new Vector2(0f, 0f), new Vector2(80f, 30f), "换弹", 18,
                     Color.white, TextAnchor.MiddleCenter);
            MakeText(interact.transform, "InteractLabel", new Vector2(0f, 0f), new Vector2(90f, 30f), "交互", 18,
                     Color.white, TextAnchor.MiddleCenter);
            MakeText(jump.transform, "JumpLabel", new Vector2(0f, 0f), new Vector2(90f, 30f), "跳", 22,
                     Color.white, TextAnchor.MiddleCenter);
            MakeText(sprint.transform, "SprintLabel", new Vector2(0f, 0f), new Vector2(80f, 30f), "疾跑", 16,
                     Color.white, TextAnchor.MiddleCenter);
            MakeText(medkit.transform, "MedkitLabel", new Vector2(0f, 0f), new Vector2(80f, 30f), "医疗", 16,
                     Color.white, TextAnchor.MiddleCenter);

            var mgrGo = new GameObject("MobileInputManager");
            var mgr = mgrGo.AddComponent<MobileInputManager>();
            mgr.moveJoystick = joy;
            mgr.lookArea = touchLook;
            mgr.fireButton = fireBtn;
            mgr.reloadButton = reload.gameObject.GetComponent<MobileButton>();
            mgr.interactButton = interact.gameObject.GetComponent<MobileButton>();
            mgr.jumpButton = jump.gameObject.GetComponent<MobileButton>();
            mgr.sprintButton = sprint.gameObject.GetComponent<MobileButton>();
            mgr.medkitButton = medkit.gameObject.GetComponent<MobileButton>();
        }

        // ====================================================================
        // 小地图
        // ====================================================================
        static void MakeMinimap(Transform root)
        {
            var bg = MakeImage(root, "Minimap", new Vector2(760f, 400f), new Vector2(220f, 220f),
                               new Color(0f, 0f, 0f, 0.6f));
            var mapRect = MakeImage(bg.transform, "MapArea", new Vector2(0f, 0f), new Vector2(200f, 200f),
                                    new Color(0.2f, 0.25f, 0.2f, 1f));
            var markerTemplate = MakeImage(mapRect.transform, "MarkerTemplate", new Vector2(0f, 0f),
                                           new Vector2(10f, 10f), Color.white);
            markerTemplate.gameObject.SetActive(false);

            var ui = bg.gameObject.AddComponent<MinimapUI>();
            ui.mapRect = (RectTransform)mapRect.transform;
            ui.markerPrefab = (RectTransform)markerTemplate.transform;
            ui.mapScale = 0.02f;
            ui.mapCenter = Vector3.zero;
        }
    }
}
