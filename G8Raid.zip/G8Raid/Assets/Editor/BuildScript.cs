using UnityEditor;
using UnityEngine;

namespace G8Raid.EditorTools
{
    /// <summary>
    /// 命令行 / CI 打包入口。
    /// 云端执行：Unity -batchmode -executeMethod G8Raid.EditorTools.BuildScript.BuildAndroid
    /// 会自动先调用 GameSceneBuilder 生成完整场景，再打包 Android APK。
    /// </summary>
    public static class BuildScript
    {
        public static void BuildAndroid()
        {
            // 0) 配置 Android 构建参数（不依赖 ProjectSettings 文件）
            PlayerSettings.productName = "G8Raid";
            PlayerSettings.companyName = "G8Raid";
            PlayerSettings.SetApplicationIdentifier(BuildTargetGroup.Android, "com.g8raid.game");
            PlayerSettings.Android.minSdkVersion = AndroidSdkVersions.AndroidApiLevel24;
            PlayerSettings.Android.targetSdkVersion = AndroidSdkVersions.AndroidApiLevel34;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.SetIl2CppCompilerConfiguration(BuildTargetGroup.Android, Il2CppCompilerConfiguration.Release);

            // 1) 自动生成完整场景（地面/玩家/敌人/UI/移动端触控）
            GameSceneBuilder.BuildFullScene();

            // 2) 打包 Android APK
            var options = new BuildPlayerOptions
            {
                scenes = new[] { "Assets/Scenes/Raid.unity" },
                target = BuildTarget.Android,
                locationPathName = "build/G8Raid.apk",
                options = BuildOptions.None
            };

            EditorUserBuildSettings.buildAppBundle = false;

            var report = BuildPipeline.BuildPlayer(options);
            if (report.summary.result != UnityEditor.Build.Reporting.BuildResult.Succeeded)
            {
                Debug.LogError("[G8Raid] Android 构建失败: " + report.summary.result);
                throw new System.Exception("Android 构建失败: " + report.summary.result);
            }

            Debug.Log("[G8Raid] APK 构建成功: " + report.summary.outputPath);
        }
    }
}
